//
//  EXMod14Ex02Tests.h
//  EXMod14Ex02Tests
//
//  Created by Andre Milani on 2/7/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod14Ex02Tests : SenTestCase

@end
