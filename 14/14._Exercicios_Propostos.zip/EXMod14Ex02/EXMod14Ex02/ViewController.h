//
//  ViewController.h
//  EXMod14Ex02
//
//  Created by Andre Milani on 2/7/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource>
{
    UIPickerView *myPicker;
    NSDictionary *myDictionary;
    NSArray *myKeys;
}

@property (nonatomic, retain) IBOutlet UIPickerView *myPicker;
@property (nonatomic, retain) NSDictionary *myDictionary;
@property (nonatomic, retain) NSArray *myKeys;

@end
