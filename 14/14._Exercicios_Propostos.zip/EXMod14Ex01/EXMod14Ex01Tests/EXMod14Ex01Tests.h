//
//  EXMod14Ex01Tests.h
//  EXMod14Ex01Tests
//
//  Created by Andre Milani on 2/7/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod14Ex01Tests : SenTestCase

@end
