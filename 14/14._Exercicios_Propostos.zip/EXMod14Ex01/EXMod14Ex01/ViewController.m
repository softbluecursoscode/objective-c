//
//  ViewController.m
//  EXMod14Ex01
//
//  Created by Andre Milani on 2/7/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize myPickerDouble;
@synthesize myPickerDataFoods;
@synthesize myPickerDataDrinks;

- (IBAction) showInfo
{
    // Captura o número da linha ativa em cada um dos componentes do picker
    NSInteger myRowFoods = [myPickerDouble selectedRowInComponent:0];
    NSInteger myRowDrinks = [myPickerDouble selectedRowInComponent:1];
    
    // Baseado na linha, captura o objeto string do array de objetos
    NSString *food = [myPickerDataFoods objectAtIndex:myRowFoods];
    NSString *drink = [myPickerDataDrinks objectAtIndex:myRowDrinks];
    
    // Monta uma mensagem para ser exibida na tela
    NSString *buffer = [[NSString alloc] initWithFormat:@"%@ e %@", food, drink];
    
    UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Pedido" 
                                                         message:buffer 
                                                        delegate:nil 
                                               cancelButtonTitle:@"OK" 
                                               otherButtonTitles:nil];
    [myAlertView show];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // Inicializa o array de comidas
    myPickerDataFoods = [[NSArray alloc] initWithObjects:
                         @"X-Burguer", 
                         @"X-Salada", 
                         @"X-Bacon", 
                         @"X-Egg", 
                         @"X-Tudo", 
                         nil];
    
    // Inicializa o array de bebidas
    myPickerDataDrinks = [[NSArray alloc] initWithObjects:
                          @"Coca-Cola", 
                          @"Pepsi", 
                          @"Fanta", 
                          @"Sprite", 
                          @"Água", 
                          nil];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark -
#pragma mark Picker Data Source Methods

// Número de componentes no picker
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}

// Número de linhas em cada um dos componentes do picker
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if(component == 0)
        return [myPickerDataFoods count];
    else
        return [myPickerDataDrinks count];
    
}

// Objeto existente em cada uma cas posições do picker
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if(component == 0)
        return [myPickerDataFoods objectAtIndex:row];
    else
        return [myPickerDataDrinks objectAtIndex:row];
}

@end
