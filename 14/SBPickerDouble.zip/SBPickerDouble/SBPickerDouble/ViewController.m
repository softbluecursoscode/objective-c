//
//  ViewController.m
//  SBPickerDouble
//
//  Created by Andre Milani on 29/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize myPickerDouble;
@synthesize myPickerData;
@synthesize myPickerDataFlavours;

// Exibe os dados selecionados no picker na tela

- (IBAction) showInfo
{
    // Captura o valor do componente 1
    
    NSInteger myRow = [myPickerDouble selectedRowInComponent:0];
    NSString *myValue = [myPickerData objectAtIndex:myRow];
    
    // Captura o valor do componente 2
    
    NSInteger myRowFlavour = [myPickerDouble selectedRowInComponent:1];
    NSString *myValueFlavour = [[myPickerDataFlavours objectAtIndex:myRow] objectAtIndex:myRowFlavour];
    
    // Cria a mensagem
    
    NSString *myMessage = [[NSString alloc] initWithFormat:@"%@ (%@)", myValue, myValueFlavour];
    
    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Informação"
                                                      message:myMessage
                                                     delegate:nil
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [myAlert show];
}

- (void)viewDidLoad
{
    // Dados do componente 1
    
    self.myPickerData = [[NSArray alloc] initWithObjects:
                         @"Suco", @"Refrigerante", @"Cerveja",
                         @"Drink", @"Caipirinha", nil];
    
    // Dados do componente 2
    
    self.myPickerDataFlavours = [[NSArray alloc] initWithObjects:
[[NSArray alloc] initWithObjects:@"Laranja", @"Uva", @"Abacaxi", nil],
[[NSArray alloc] initWithObjects:@"Cola", @"Limão", @"Guaraná", nil],
[[NSArray alloc] initWithObjects:@"Clara", @"Escura", nil],
[[NSArray alloc] initWithObjects:@"Alexander", @"Manhattan", @"Pina Colada", nil],
[[NSArray alloc] initWithObjects:@"Limão", @"Maracujá", @"Morango", nil],
                                 nil];
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Métodos do protocolo UIPickerViewDataSource

// Número de componentes do picker

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

// Número de linhas de um determinado componente

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if(component == 0)
    {
        return [myPickerData count];
    }
    else
    {
        return [[myPickerDataFlavours objectAtIndex:[myPickerDouble selectedRowInComponent:0]] count];
    }
}

// Métodos do protocolo UIPickerViewDelegate

// Título de cada item dos componentes

- (NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if(component == 0)
    {
        return [myPickerData objectAtIndex:row];
    }
    else
    {
        return [[myPickerDataFlavours objectAtIndex:[myPickerDouble selectedRowInComponent:0]] objectAtIndex:row];
    }
}

// Ação de alterar o valor selecionado em um componente do picker

- (void) pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if(component == 0)
    {
        [myPickerDouble selectRow:0 inComponent:1 animated:TRUE];
        [myPickerDouble reloadComponent:1];
    }
}

@end
