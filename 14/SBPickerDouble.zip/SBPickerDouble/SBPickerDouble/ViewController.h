//
//  ViewController.h
//  SBPickerDouble
//
//  Created by Andre Milani on 29/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIPickerViewDataSource, UIPickerViewDelegate>
{
    UIPickerView *myPickerDouble;
    NSArray *myPickerData;
    NSArray *myPickerDataFlavours;
}

@property (nonatomic, retain) IBOutlet UIPickerView *myPickerDouble;
@property (nonatomic, retain) NSArray *myPickerData;
@property (nonatomic, retain) NSArray *myPickerDataFlavours;

-(IBAction) showInfo;

@end
