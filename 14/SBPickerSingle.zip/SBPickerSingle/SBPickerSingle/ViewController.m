//
//  ViewController.m
//  SBPickerSingle
//
//  Created by Andre Milani on 29/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize myPickerSingle;
@synthesize myPickerData;

- (void)viewDidLoad
{
    // Cria dados fictícios para a aplicação
    
    self.myPickerData = [[NSArray alloc] initWithObjects: @"Suco",
                         @"Refrigerante", @"Cerveja", @"Drink",
                         @"Caipirinha", nil];
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

// Exibe o valor selecionado no picker

- (IBAction) showInfo
{
    NSInteger myRow = [myPickerSingle selectedRowInComponent:0];
    NSString *myValue = [myPickerData objectAtIndex:myRow];
    NSString *myMessage = [[NSString alloc] initWithFormat:@"Valor: %@", myValue];
    
    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Informação"
                                                      message: myMessage
                                                     delegate:nil
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [myAlert show];
}

// Métodos do protocolo UIPickerViewDataSource

// Número de colunas (componentes) do picker

- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// Número de linhas em cada componente

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [myPickerData count];
}

// Método do protocolo UIPickerViewDelegate

// Título de cada linha do picker

- (NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [myPickerData objectAtIndex:row];
}











- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
