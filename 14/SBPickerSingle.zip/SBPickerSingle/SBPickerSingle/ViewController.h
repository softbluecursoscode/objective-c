//
//  ViewController.h
//  SBPickerSingle
//
//  Created by Andre Milani on 29/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource>
{
    UIPickerView *myPickerSingle;
    NSArray *myPickerData;
}

@property (nonatomic, retain) IBOutlet UIPickerView *myPickerSingle;
@property (nonatomic, retain) NSArray *myPickerData;

- (IBAction) showInfo;

@end
