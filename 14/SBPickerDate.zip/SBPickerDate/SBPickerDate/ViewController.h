//
//  ViewController.h
//  SBPickerDate
//
//  Created by Andre Milani on 29/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UIDatePicker *myPickerDate;
}

@property (nonatomic, retain) IBOutlet UIDatePicker *myPickerDate;

- (IBAction) showInfo;

@end
