//
//  ViewController.m
//  SBPickerDate
//
//  Created by Andre Milani on 29/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize myPickerDate;

- (IBAction) showInfo
{
    NSDate *myDate = [myPickerDate date];
    
    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Informação"
               message: [[NSString alloc] initWithFormat: @"%@", myDate]
               delegate: nil
               cancelButtonTitle:@"OK"
               otherButtonTitles:nil];
    [myAlert show];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
