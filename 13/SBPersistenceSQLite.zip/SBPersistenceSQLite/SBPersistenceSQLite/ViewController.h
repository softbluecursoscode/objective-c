//
//  ViewController.h
//  SBPersistenceSQLite
//
//  Created by Andre Milani on 03/11/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UITextField *fieldFirstName;
    UITextField *fieldLastName;
    UITextField *fieldEmail;
}

@property (nonatomic, retain) IBOutlet UITextField *fieldFirstName;
@property (nonatomic, retain) IBOutlet UITextField *fieldLastName;
@property (nonatomic, retain) IBOutlet UITextField *fieldEmail;

- (NSString *) getFilepath;
- (void) applicationWillResignActiveNotificationFunction: (NSNotification *) notification;

@end
