//
//  ViewController.m
//  SBPersistenceSQLite
//
//  Created by Andre Milani on 03/11/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

/*
 
 FIELDS
 ===========================
 FIELD_NAME     | FIELD_DATA
 ===========================
 fieldFirstName | andre
 fieldLastName  | milani
 fieldEmail     | teste@gmail.com
 
 */

#import "ViewController.h"
#import "sqlite3.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize fieldFirstName;
@synthesize fieldLastName;
@synthesize fieldEmail;

- (NSString *) getFilepath
{
    NSArray *userDomainPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDir = [userDomainPaths objectAtIndex:0];
    
    return [documentsDir stringByAppendingPathComponent:@"myDatabase"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

    // Cria o banco de dados caso não exista
    
    sqlite3 *myDatabase;
    
    if(sqlite3_open([[self getFilepath] UTF8String], &myDatabase) != SQLITE_OK)
    {
        NSAssert(FALSE, @"Falha na abertura do banco no método viewDidLoad");
    }
    
    NSString *createSQL = @"CREATE TABLE IF NOT EXISTS FIELDS (FIELD_NAME TEXT PRIMARY KEY, FIELD_DATA TEXT);";
    
    char *errorMsg;
    
    if(sqlite3_exec(myDatabase, [createSQL UTF8String], NULL, NULL, &errorMsg) != SQLITE_OK)
    {
        sqlite3_close(myDatabase);
        NSAssert1(FALSE, @"Ocorreu um erro: %s", errorMsg);
    }
    
    // Lê os dados da tabela caso já existam dados cadastrados
    
    NSString *query = @"SELECT FIELD_NAME, FIELD_DATA FROM FIELDS";
    
    sqlite3_stmt *statement;
    
    if(sqlite3_prepare_v2(myDatabase, [query UTF8String], -1, &statement, nil) == SQLITE_OK)
    {
        while(sqlite3_step(statement) == SQLITE_ROW)
        {
            // Lê o nome do campo
            char *rowName = (char *) sqlite3_column_text(statement, 0);
            
            // Lê o valor do campo
            char *rowData = (char *) sqlite3_column_text(statement, 1);
            
            NSString *fieldName = [[NSString alloc] initWithUTF8String:rowName];
            NSString *fieldData = [[NSString alloc] initWithUTF8String:rowData];
            
            // Acessa dinamicamente a IBOutlet em questão e popula seu valor
            UITextField *field = [self valueForKey:fieldName];
            field.text = fieldData;
        }
        
        sqlite3_finalize(statement);
    }
    
    sqlite3_close(myDatabase);
    
    // Cadastra o observer que salvará os dados quando a aplicação encerrar
    
    UIApplication *app = [UIApplication sharedApplication];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillResignActiveNotificationFunction:) name:UIApplicationWillResignActiveNotification object:app];
}

- (void) applicationWillResignActiveNotificationFunction:(NSNotification *)notification
{
    // Salva os dados no banco
    
    sqlite3 *myDatabase;
    
    if(sqlite3_open([[self getFilepath] UTF8String], &myDatabase) != SQLITE_OK)
    {
        NSAssert(FALSE, @"Falha na abertura do banco no método applicationWillResignActiveNotificationFunction");
    }
    
    NSArray *fieldNames = [[NSArray alloc] initWithObjects:@"fieldFirstName", @"fieldLastName", @"fieldEmail", nil];
    
    for(int i=0; i<3; i++)
    {
        NSString *fieldName = [fieldNames objectAtIndex:i];
        
        UITextField *field = [self valueForKey:fieldName];
        
        char *update = "INSERT OR REPLACE INTO FIELDS (FIELD_NAME, FIELD_DATA) VALUES (?, ?);";
        
        sqlite3_stmt *statement;
        
        if(sqlite3_prepare_v2(myDatabase, update, -1, &statement, nil) == SQLITE_OK)
        {
            sqlite3_bind_text(statement, 1, [[fieldNames objectAtIndex:i] UTF8String], -1, NULL);
            
            sqlite3_bind_text(statement, 2, [field.text UTF8String], -1, NULL);
        }
        
        if(sqlite3_step(statement) != SQLITE_DONE)
        {
            NSAssert1(FALSE, @"Erro no banco de dados: %s", sqlite3_errmsg(myDatabase));
        }
        
        sqlite3_finalize(statement);
    }
    
    sqlite3_close(myDatabase);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
