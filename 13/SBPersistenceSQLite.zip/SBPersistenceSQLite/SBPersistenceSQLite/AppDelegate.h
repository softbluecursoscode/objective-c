//
//  AppDelegate.h
//  SBPersistenceSQLite
//
//  Created by Andre Milani on 03/11/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
