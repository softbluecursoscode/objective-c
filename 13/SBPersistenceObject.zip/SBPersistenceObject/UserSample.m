//
//  UserSample.m
//  SBPersistenceObject
//
//  Created by Andre Milani on 31/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "UserSample.h"

@implementation UserSample

@synthesize fieldFirstName;
@synthesize fieldLastName;
@synthesize fieldEmail;

// Método de serialização definido pelo protocolo NSCoding

- (void) encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:fieldFirstName forKey:@"fieldFirstNameStringKey"];
    [aCoder encodeObject:fieldLastName forKey:@"fieldLastNameStringKey"];
    [aCoder encodeObject:fieldEmail forKey:@"fieldEmailStringKey"];
}

// Método de desserialização definido pelo protocolo NSCoding

- (id) initWithCoder:(NSCoder *)aDecoder
{
    if(self = [super init])
    {
        fieldFirstName = [aDecoder decodeObjectForKey:@"fieldFirstNameStringKey"];
        fieldLastName = [aDecoder decodeObjectForKey:@"fieldLastNameStringKey"];
        fieldEmail = [aDecoder decodeObjectForKey:@"fieldEmailStringKey"];
    }
    
    return self;
}

// Método de cópia definido pelo protocolo NSCopying

- (id) copyWithZone:(NSZone *)zone
{
    UserSample *myUserSample =[[[self class] allocWithZone:zone] init];
    
    myUserSample.fieldFirstName = [self.fieldFirstName copyWithZone:zone];
    myUserSample.fieldLastName = [self.fieldLastName copyWithZone:zone];
    myUserSample.fieldEmail = [self.fieldEmail copyWithZone:zone];
    
    return myUserSample;
}


@end
