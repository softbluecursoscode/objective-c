//
//  UserSample.h
//  SBPersistenceObject
//
//  Created by Andre Milani on 31/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserSample : NSObject <NSCoding, NSCopying>
{
    NSString *fieldFirstName;
    NSString *fieldLastName;
    NSString *fieldEmail;
}

@property (nonatomic, retain) NSString *fieldFirstName;
@property (nonatomic, retain) NSString *fieldLastName;
@property (nonatomic, retain) NSString *fieldEmail;

@end
