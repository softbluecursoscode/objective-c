//
//  ViewController.m
//  SBPersistenceObject
//
//  Created by Andre Milani on 31/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"
#import "UserSample.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize fieldFirstName;
@synthesize fieldLastName;
@synthesize fieldEmail;

- (NSString *) getFilepath;
{
    NSArray *userDomainPaths = NSSearchPathForDirectoriesInDomains(NSDocumentationDirectory, NSUserDomainMask, YES);
    
    NSString *documentDir = [userDomainPaths objectAtIndex:0];
    
    return [documentDir stringByAppendingString:@"encodedObjectFile"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    NSString *filepath = [self getFilepath];
    
    // Verifica existência do arquivo com os dados para leitura
    
    if([[NSFileManager defaultManager] fileExistsAtPath:filepath])
    {
        NSData *data = [[NSMutableData alloc] initWithContentsOfFile:filepath];
        
        // Prepara o objeto para ser desserializado
        
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
        
        UserSample *userSample = [unarchiver decodeObjectForKey:@"Data"];
        [unarchiver finishDecoding];
        
        fieldFirstName.text = userSample.fieldFirstName;
        fieldLastName.text = userSample.fieldLastName;
        fieldEmail.text = userSample.fieldEmail;
    }
    
    // Cria o observer que salva os dados quando a aplicação encerra
    
    UIApplication *app = [UIApplication sharedApplication];
    [[NSNotificationCenter defaultCenter]
     addObserver:self
    selector:@selector(applicationWillResignActiveNotificationFunction:)
     name:UIApplicationWillResignActiveNotification
     object:app];
}

- (void) applicationWillResignActiveNotificationFunction:(NSNotification *)notification
{
    // Prepara o objeto para ser serializado e gravado em arquivo
    
    UserSample *userSample = [[UserSample alloc] init];
    userSample.fieldFirstName = fieldFirstName.text;
    userSample.fieldLastName = fieldLastName.text;
    userSample.fieldEmail = fieldEmail.text;
    
    NSMutableData *data = [[NSMutableData alloc] init];
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
    [archiver encodeObject:userSample forKey:@"Data"];
    [archiver finishEncoding];
    
    [data writeToFile:[self getFilepath] atomically:TRUE];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
