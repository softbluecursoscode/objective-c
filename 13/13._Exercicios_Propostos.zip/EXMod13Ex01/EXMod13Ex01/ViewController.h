//
//  ViewController.h
//  EXMod13Ex01
//
//  Created by Andre Milani on 2/7/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UILabel *myLabel;
}

@property (nonatomic, retain) IBOutlet UILabel *myLabel;

- (NSString *) getFilepath;
- (void) updateFile;
- (void)applicationWillResignActiveNotificationFunction:(NSNotification *)notification;

@end
