//
//  ViewController.m
//  EXMod13Ex01
//
//  Created by Andre Milani on 2/7/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize myLabel;

- (NSString *) getFilepath
{
    // Define um endereço de arquivo para o arquivo que será utilizado
    NSArray *userDomainPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, 
                                                                   NSUserDomainMask, 
                                                                   YES);
    NSString *documentsDir = [userDomainPaths objectAtIndex:0];
    return [documentsDir stringByAppendingPathComponent:@"programRuns.plist"];
}

- (void) updateFile
{
    // Captura o endereço do arquivo
    NSString *filepath = [self getFilepath];
    
    // Verifica a existência do arquivo
    if([[NSFileManager defaultManager] fileExistsAtPath:filepath]) {
        
        // Lê o arquivo para um array
        NSMutableArray *array = [[NSMutableArray alloc] initWithContentsOfFile:filepath];
        
        // Carrega a label na tela
        myLabel.text = [array objectAtIndex:0];
        
        // Incrementa em 1
        NSInteger manyTimes = [myLabel.text intValue];
        manyTimes++;
        
        // E atualiza o arquivo
        [array removeAllObjects];
        [array addObject:[[NSString alloc] initWithFormat:@"%d", manyTimes]];
        [array writeToFile:[self getFilepath] atomically:YES];
    }   
}

- (void)applicationWillResignActiveNotificationFunction:(NSNotification *)notification {
    [self updateFile];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // Adiciona um observer para invocar um método toda vez que a aplicação voltar a executar
    UIApplication *app = [UIApplication sharedApplication];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(applicationWillResignActiveNotificationFunction:)
												 name:UIApplicationWillResignActiveNotification
											   object:app];
    
    // Invoca a primeira vez para atualizar a tela
    [self updateFile];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
