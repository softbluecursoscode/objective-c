//
//  InstrumentoMusical.h
//  EXMod13Ex02
//
//  Created by Andre Milani on 2/8/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>

/* Implementa o NSCoding para empacotamento/desempacotamento */
@interface InstrumentoMusical : NSObject <NSCoding>
{
    NSString *marca;
    NSString *modelo;
    NSString *isEletrico;
    NSString *numeroDeCordas;
}

@property (nonatomic, retain) NSString *marca;
@property (nonatomic, retain) NSString *modelo;
@property (nonatomic, retain) NSString *isEletrico;
@property (nonatomic, retain) NSString *numeroDeCordas;
 
@end
