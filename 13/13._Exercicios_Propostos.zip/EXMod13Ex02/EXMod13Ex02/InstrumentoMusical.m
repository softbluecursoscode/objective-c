//
//  InstrumentoMusical.m
//  EXMod13Ex02
//
//  Created by Andre Milani on 2/8/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "InstrumentoMusical.h"

@implementation InstrumentoMusical

@synthesize marca;
@synthesize modelo;
@synthesize isEletrico;
@synthesize numeroDeCordas;

#pragma mark NSCoding

// Método de empacotamento
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:marca forKey:@"keyMarca"];
    [aCoder encodeObject:modelo forKey:@"keyModelo"];
    [aCoder encodeObject:isEletrico forKey:@"keyIsEletrico"];
    [aCoder encodeObject:numeroDeCordas forKey:@"keyNumeroDeCordas"];
}

// Método de desempacotamento
- (id)initWithCoder:(NSCoder *)aDecoder
{
    if(self == [super init]) 
    {
        marca = [aDecoder decodeObjectForKey:@"keyMarca"];
        modelo = [aDecoder decodeObjectForKey:@"keyModelo"];
        isEletrico = [aDecoder decodeObjectForKey:@"keyIsEletrico"];
        numeroDeCordas = [aDecoder decodeObjectForKey:@"keyNumeroDeCordas"];
    }
    
    return self;
}
 
@end
