//
//  ViewController.h
//  EXMod13Ex02
//
//  Created by Andre Milani on 2/8/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InstrumentoMusical.h"

@interface ViewController : UIViewController
{
    // Campos do formulário, já com a label auxiliar do slider (exibição de seu valor)
    UITextField *fieldMarca;
    UITextField *fieldModelo;
    UISwitch *fieldIsEletrico;
    UISlider *fieldNumeroDeCordas;
    UILabel *labelAuxSlider;
}

@property (nonatomic, retain) IBOutlet UITextField *fieldMarca;
@property (nonatomic, retain) IBOutlet UITextField *fieldModelo;
@property (nonatomic, retain) IBOutlet UISwitch *fieldIsEletrico;
@property (nonatomic, retain) IBOutlet UISlider *fieldNumeroDeCordas;
@property (nonatomic, retain) IBOutlet UILabel *labelAuxSlider;

// Tratamento do retorno do teclado
- (IBAction)textFieldReturn:(id)sender;

// Atualização da label do slider quando o mesmo for alterado
- (IBAction) sliderChangedValue;

// Caminho do arquivo onde o objeto será armazenado
- (NSString *) getFilepath;

// Funções solicitadas pelo exercício
- (IBAction) salvar;
- (IBAction) carregar;
- (IBAction) resetar;

@end
