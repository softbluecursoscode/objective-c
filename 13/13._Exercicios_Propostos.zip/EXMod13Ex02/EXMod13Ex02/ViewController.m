//
//  ViewController.m
//  EXMod13Ex02
//
//  Created by Andre Milani on 2/8/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize fieldMarca;
@synthesize fieldModelo;
@synthesize fieldIsEletrico;
@synthesize fieldNumeroDeCordas;
@synthesize labelAuxSlider;

- (IBAction)textFieldReturn:(id)sender {
    [sender resignFirstResponder];
}

- (IBAction) sliderChangedValue
{
    labelAuxSlider.text = [[NSString alloc] initWithFormat:@"%d", (int) [fieldNumeroDeCordas value]];
}

- (NSString *) getFilepath
{
    NSArray *userDomainPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, 
                                                                   NSUserDomainMask, 
                                                                   YES);
    NSString *documentsDir = [userDomainPaths objectAtIndex:0];
    return [documentsDir stringByAppendingPathComponent:@"objectStored"];
}

- (IBAction) salvar
{
    // Método de salvar: empacota o objeto, tratando o Switch e o Slider de forma exclusiva
    
    InstrumentoMusical *instrumento = [[InstrumentoMusical alloc] init];
    instrumento.marca = fieldMarca.text;
    instrumento.modelo = fieldModelo.text;
    instrumento.isEletrico = fieldIsEletrico.on ? @"TRUE" : @"FALSE";
    instrumento.numeroDeCordas = labelAuxSlider.text;
    
    // Empacotamento e criação/atualização do arquivo
    
    NSMutableData *data = [[NSMutableData alloc] init];
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
    [archiver encodeObject:instrumento forKey:@"Data"];
    [archiver finishEncoding];
    [data writeToFile:[self getFilepath] atomically:TRUE];
}

- (IBAction) carregar
{
    NSString *filepath = [self getFilepath];
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:filepath]) {
        
        // Havendo alguma versão salva, a mesma é carregada neste método de desempacotamento
        NSData *data = [[NSMutableData alloc] initWithContentsOfFile:[self getFilepath]];
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
        
        InstrumentoMusical *instrumento = [unarchiver decodeObjectForKey:@"Data"];
        [unarchiver finishDecoding];
        
        // População dos campos do formulário, tratando Switch e Slider de forma apropriada
        
        fieldMarca.text = instrumento.marca;
        fieldModelo.text = instrumento.modelo;
        fieldIsEletrico.on = [instrumento.isEletrico isEqualToString:@"TRUE"] ? TRUE : FALSE;
        fieldNumeroDeCordas.value = [instrumento.numeroDeCordas floatValue];
        labelAuxSlider.text = [[NSString alloc] initWithFormat:@"%d", [instrumento.numeroDeCordas intValue]];
    }
}

- (IBAction) resetar
{
    // Reseta os campos para seus valores iniciais, sem alterar o arquivo
    
    fieldMarca.text = @"";
    fieldModelo.text = @"";
    fieldIsEletrico.on = true;
    fieldNumeroDeCordas.value = (float)6;
    labelAuxSlider.text = @"6";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
