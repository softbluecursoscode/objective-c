//
//  EXMod13Ex02Tests.h
//  EXMod13Ex02Tests
//
//  Created by Andre Milani on 2/8/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod13Ex02Tests : SenTestCase

@end
