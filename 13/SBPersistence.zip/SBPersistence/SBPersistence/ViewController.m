//
//  ViewController.m
//  SBPersistence
//
//  Created by Andre Milani on 31/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize fieldEmail;
@synthesize fieldFirstName;
@synthesize fieldLastName;

- (NSString *) getFilepath
{
    NSArray *userDomainPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *documentsDir = [userDomainPaths objectAtIndex:0];
    
    return [documentsDir stringByAppendingPathComponent:@"myFile.plist"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    NSString *filepath = [self getFilepath];
    
    // Verifica existência do arquivo de dados e lê, caso exista
    
    if([[NSFileManager defaultManager] fileExistsAtPath:filepath])
    {
        NSArray *array = [[NSArray alloc] initWithContentsOfFile:filepath];
        fieldFirstName.text = [array objectAtIndex:0];
        fieldLastName.text = [array objectAtIndex:1];
        fieldEmail.text = [array objectAtIndex:2];
    }
    
    // Adiciona um observer para salvar os dados quando a aplicação encerrar
    
    UIApplication *app = [UIApplication sharedApplication];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(applicationWillResignActiveNotificationFunctions:)
     name:UIApplicationWillResignActiveNotification
     object:app];
}

// Salva os dados ao sair da aplicação

- (void) applicationWillResignActiveNotificationFunctions:(NSNotification *)notification
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    [array addObject:fieldFirstName.text];
    [array addObject:fieldLastName.text];
    [array addObject:fieldEmail.text];
    
    [array writeToFile:[self getFilepath] atomically:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
