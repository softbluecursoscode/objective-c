//
//  ViewController.h
//  SBPersistence
//
//  Created by Andre Milani on 31/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UITextField *fieldFirstName;
    UITextField *fieldLastName;
    UITextField *fieldEmail;
}

@property (nonatomic, retain) IBOutlet UITextField *fieldFirstName;
@property (nonatomic, retain) IBOutlet UITextField *fieldLastName;
@property (nonatomic, retain) IBOutlet UITextField *fieldEmail;

- (NSString *) getFilepath;
- (void) applicationWillResignActiveNotificationFunctions: (NSNotification *) notification;

@end
