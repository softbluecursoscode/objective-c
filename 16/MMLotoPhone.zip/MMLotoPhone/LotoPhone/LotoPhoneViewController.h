//
//  LotoPhoneViewController.h
//  LotoPhone
//
//  Created by André Milani on 6/27/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LotoPhoneViewController : UIViewController {
    UILabel *resultLabel;
}

@property (nonatomic, retain) IBOutlet UILabel *resultLabel;

- (IBAction) generateGameMegaSena:(id)sender;

@end
