//
//  LotoPhoneAppDelegate.h
//  LotoPhone
//
//  Created by André Milani on 6/27/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LotoPhoneViewController;

@interface LotoPhoneAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet LotoPhoneViewController *viewController;

@end
