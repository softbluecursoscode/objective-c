//
//  LotoPhoneViewController.m
//  LotoPhone
//
//  Created by André Milani on 6/27/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import "LotoPhoneViewController.h"

@implementation LotoPhoneViewController

@synthesize resultLabel;

- (void)dealloc
{
    [resultLabel release];
    [super dealloc];
}

//
// Gerador de jogos para loteria federal
//
- (IBAction) generateGameMegaSena:(id)sender {
    
    int numbers = 0;    // Quantos números compõem um jogo
    int from = 0;       // Qual o número inicial (mínimo)
    int to = 0;         // Qual o número final (máximo)
    
    int tag = ((UIButton*)sender).tag ;
    
    switch(tag) {
        case 0:         // Mega-Sena
            numbers = 6;
            from = 1;
            to = 60;
            break;
            
        case 1:         // Quina
            numbers = 5;
            from = 1;
            to = 80;
            break;
            
        case 2:         // Lotofácil
            numbers = 15;
            from = 1;
            to = 25;
            break;
    }
    
    // Trata tipo de jogo inválido (para jogos ainda não implementados)
    if(numbers == 0) {
        UIAlertView *alert = [[UIAlertView alloc] 
                              initWithTitle:@"Ups!" 
                              message:@"Não foram localizadas configurações para o jogo selecionado." 
                              delegate:self 
                              cancelButtonTitle:@"OK" 
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    else {
        
        // Cria um array de números inteiros randômicos
        int game[numbers];
        
        // Para cada um dos números...
        for(int x=0; x<numbers; x++) {
            while(true) {
                
                // Gera um novo número randômico
                game[x] = (arc4random() % (to - from + 1)) + 1;
                
                // E verifica se não é repetido
                bool canContinue = TRUE;
                for(int y=0; y<x; y++) {
                    if(game[x] == game[y])
                        canContinue = FALSE;
                }
                
                if(canContinue)
                    break;
            }
        }
        
        // Ordena o array em ordem crescente
        for(int x=0; x<numbers; x++) {
            for(int y=x+1; y<numbers; y++) {
                if(game[x] < game[y]) {
                    int temp = game[x];
                    game[x] = game[y];
                    game[y] = temp;
                }
            }
        }
        
        // Formata para visualização
        NSString *fullGame = [[NSString alloc] initWithFormat:@""];
        for(int x=0; x<numbers; x++) {
            fullGame = [[NSString alloc] initWithFormat:@"%d %s", game[x], [fullGame UTF8String]];
        }
        
        // Apresenta o resultado na label
        resultLabel.text = fullGame;
        
        [fullGame release];
    }    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    // Define o fundo de tela
    self.view.backgroundColor = [[UIColor alloc] 
                                 initWithPatternImage:[UIImage 
                                                       imageNamed:@"LotoPhoneBackground.png"]];
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self.resultLabel = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
