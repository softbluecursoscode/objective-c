//
//  AmormetroAppDelegate.h
//  Amormetro
//
//  Created by André Milani on 6/19/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AmormetroViewController;

@interface AmormetroAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet AmormetroViewController *viewController;

@end
