//
//  AmormetroViewController.m
//  Amormetro
//
//  Created by André Milani on 6/19/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import "AmormetroViewController.h"

@implementation AmormetroViewController

@synthesize userNameLabel;
@synthesize partnerNameLabel;
@synthesize userName;
@synthesize partnerName;
@synthesize result;
@synthesize button;

//
// Calcula o resultado baseado na fórmula: soma dos valores ASCII dos caracteres,
// obtendo o resto da divisão por 100 para garantir um valor entre 0 e 100
//
- (IBAction)calculate:(id)sender {
    
    // Captura os nomes digitados pelo usuário
    NSString *userNameStr = [[NSString alloc] initWithString:userName.text];
    NSString *partnerNameStr = [[NSString alloc] initWithString:partnerName.text];
    
    
    // Verifica se ambos os campos possuem algum texto
    if([userNameStr length] == 0 || [partnerNameStr length] == 0) {
        UIAlertView *alert = [[UIAlertView alloc] 
                              initWithTitle:NSLocalizedString(@"Alert title", nil)
                              message:NSLocalizedString(@"Alert both names", nil) 
                              delegate:self 
                              cancelButtonTitle:NSLocalizedString(@"Button accept", nil) 
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
        
        [userNameStr release];
        [partnerNameStr release];
        
        return;
    }
    
    // Soma os valores dos caracteres ASCII de cada letra
    int asciiPointsUserName = 0;
    int asciiPointsPartnerName = 0;
    
    for(int x=0; x<[userNameStr length]; x++) {
        asciiPointsUserName += (int)[userNameStr characterAtIndex:x];
    }
    
    for(int x=0; x<[partnerNameStr length]; x++) {
        asciiPointsPartnerName += (int)[partnerNameStr characterAtIndex:x];
    }
    
    // Para que a soma fique entre 0 e 100, calcula o resto da divisão do total por 100
    int resultPoints = (asciiPointsUserName + asciiPointsPartnerName + 100) % 100;
    result.text = @"";
    
    // Validação especial para 2 nomes pré-configurados
    if(hasTheseNames([userNameStr UTF8String], [partnerNameStr UTF8String], "andre", "fulana")
       || hasTheseNames([userNameStr UTF8String], [partnerNameStr UTF8String], "andré", "fulana")) {
        
        UIAlertView *alert = [[UIAlertView alloc] 
                              initWithTitle:NSLocalizedString(@"Alert title", nil)
                              message:NSLocalizedString(@"Alert cannot execute", nil)
                              delegate:self 
                              cancelButtonTitle:NSLocalizedString(@"Button accept", nil)
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    else {
        // Exibe o resultado na tela caso não sejam os nomes pré-configurados acima
        result.text = [[NSString alloc] initWithFormat:@"%d%%", resultPoints];
    }
    
    [userNameStr release];
    [partnerNameStr release];
}

//
// Implementa o retorno do teclado para fechá-lo após digitar os nomes
//
- (IBAction)textFieldDoneEditing:(id)sender {
    [sender resignFirstResponder];
}

//
// Implementa o fechamento do teclado baseado no toque no fundo da tela (opcional)
//
- (IBAction)backgroundTap:(id)sender {
    [userName resignFirstResponder];
    [partnerName resignFirstResponder];
}

//
// Verifica a existência de 2 nomes específicos
//
bool hasTheseNames(char* userName, char* partnerName, char* nameA, char* nameB) {
    
    // Nomes digitados pelo usuário
    NSString *nsUserName = [[NSString alloc] initWithFormat:@"%s", userName];
    NSString *nsPartnerName = [[NSString alloc] initWithFormat:@"%s", partnerName];
    
    // Nomes pré-configurados a serem pesquisados
    NSString *nsNameA = [[NSString alloc] initWithFormat:@"%s", nameA];
    NSString *nsNameB = [[NSString alloc] initWithFormat:@"%s", nameB];
    
    NSRange r1, r2, r3, r4;
    r1 =[[nsUserName lowercaseString] rangeOfString:[nsNameA lowercaseString]];
    r2 =[[nsUserName lowercaseString] rangeOfString:[nsNameB lowercaseString]];
    r3 =[[nsPartnerName lowercaseString] rangeOfString:[nsNameA lowercaseString]];
    r4 =[[nsPartnerName lowercaseString] rangeOfString:[nsNameB lowercaseString]];
    
    // Se não encontrar o nome nsNameA e nem nsNameB em nsUserName, retorna falso pois
    // um dos nomes já garante a condição de não ser um "casal" pré-determinado
    if(r1.location == NSNotFound && r2.location == NSNotFound)
        return false;
    
    // O mesmo para o segundo campo (procurando os nomes nsNameA e nsNameB em nsPartnerName)
    else if(r3.location == NSNotFound && r4.location == NSNotFound)
        return false;
    
    // Se chegar neste bloco, é porque ambos os nomes constam nos campos
    else
        return true;
}

- (void)dealloc
{
    [userNameLabel release];
    [partnerNameLabel release];
    [userName release];
    [partnerName release];
    [result release];
    [button release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    // Define o fundo de tela
    self.view.backgroundColor = [[UIColor alloc] 
                                 initWithPatternImage:[UIImage 
                                                       imageNamed:@"AmormetroBackground_iPhone.png"]];
    
    // Define os textos das labels e o título do botão
    userNameLabel.text = NSLocalizedString(@"User label", nil);
    partnerNameLabel.text = NSLocalizedString(@"Partner label", nil);
    [button setTitle: NSLocalizedString(@"Button title", nil) forState: UIControlStateNormal];
    
    [super viewDidLoad];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    self.userNameLabel = nil;
    self.partnerNameLabel = nil;
    self.userName = nil;
    self.partnerName = nil;
    self.result = nil;
    self.button = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
