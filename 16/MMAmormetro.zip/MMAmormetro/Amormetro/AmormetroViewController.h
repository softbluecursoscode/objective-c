//
//  AmormetroViewController.h
//  Amormetro
//
//  Created by André Milani on 6/19/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <iAd/iAd.h>

@interface AmormetroViewController : UIViewController <ADBannerViewDelegate> {
    
    UILabel *userNameLabel;
    UILabel *partnerNameLabel;
    UITextField *userName;
    UITextField *partnerName;
    UILabel *result;
    UIButton *button;
    
    ADBannerView *adView;
    BOOL bannerIsVisible;

}

@property (nonatomic, retain) IBOutlet UILabel *userNameLabel;
@property (nonatomic, retain) IBOutlet UILabel *partnerNameLabel;
@property (nonatomic, retain) IBOutlet UITextField *userName;
@property (nonatomic, retain) IBOutlet UITextField *partnerName;
@property (nonatomic, retain) IBOutlet UILabel *result;
@property (nonatomic, retain) IBOutlet UIButton *button;

- (IBAction)textFieldDoneEditing:(id)sender;
- (IBAction)backgroundTap:(id)sender;
- (IBAction)calculate:(id)sender;

bool hasTheseNames(char* userName, char* partnerName, char* nameA, char* nameB);

@end
