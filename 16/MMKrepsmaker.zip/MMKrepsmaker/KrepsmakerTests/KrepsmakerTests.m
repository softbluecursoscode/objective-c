//
//  KrepsmakerTests.m
//  KrepsmakerTests
//
//  Created by André Milani on 6/21/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import "KrepsmakerTests.h"


@implementation KrepsmakerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in KrepsmakerTests");
}

@end
