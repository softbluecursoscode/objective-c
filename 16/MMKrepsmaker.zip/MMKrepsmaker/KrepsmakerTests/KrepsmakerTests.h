//
//  KrepsmakerTests.h
//  KrepsmakerTests
//
//  Created by André Milani on 6/21/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface KrepsmakerTests : SenTestCase {
@private
    
}

@end
