//
//  KrepsmakerAppDelegate.h
//  Krepsmaker
//
//  Created by André Milani on 6/21/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@class KrepsmakerViewController;

@interface KrepsmakerAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet KrepsmakerViewController *viewController;

@end
