//
//  KrepsmakerViewController.h
//  Krepsmaker
//
//  Created by André Milani on 6/21/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KrepsmakerViewController : UIViewController {
    UILabel *sliderLabel;
    UILabel *massaLabel;
    UILabel *recheiosLabel;
    UILabel *bebidasLabel;
    UILabel *preparoLabel;
}

@property (nonatomic, retain) IBOutlet UILabel *sliderLabel;
@property (nonatomic, retain) IBOutlet UILabel *massaLabel;
@property (nonatomic, retain) IBOutlet UILabel *recheiosLabel;
@property (nonatomic, retain) IBOutlet UILabel *bebidasLabel;
@property (nonatomic, retain) IBOutlet UILabel *preparoLabel;

- (IBAction)sliderChanged:(id)sender;
- (IBAction)segmentChanged:(id)sender;

@end
