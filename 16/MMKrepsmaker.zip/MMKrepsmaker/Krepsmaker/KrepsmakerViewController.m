//
//  KrepsmakerViewController.m
//  Krepsmaker
//
//  Created by André Milani on 6/21/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import "KrepsmakerViewController.h"

@implementation KrepsmakerViewController

@synthesize sliderLabel;
@synthesize massaLabel;
@synthesize recheiosLabel;
@synthesize bebidasLabel;
@synthesize preparoLabel;

//
// Atualiza a receita de acordo com o número de pessoas definido no slider
//
- (IBAction)sliderChanged:(id)sender {
    
    // Atualiza o número de pessoas na tela
    
    UISlider *slider = (UISlider *)sender;
    int pessoas = (int)(slider.value + 0.5f);
    sliderLabel.text = [[NSString alloc] initWithFormat:@"%d pessoas", pessoas];

    // Realiza o cálculo do número de receitas e quantidades
    
    int pessoasPorReceita = 4;
    int quantidadeDeReceitas = ceil((float)pessoas / (float)pessoasPorReceita);
    
    int xicarasFarinha      = 2   * quantidadeDeReceitas;
    int xicarasLeite        = 2   * quantidadeDeReceitas;
    int xicarasAmidoMilho   = 1   * quantidadeDeReceitas;
    int ovos                = 1   * quantidadeDeReceitas;
    int colheresSal         = 1   * quantidadeDeReceitas;
    int colheresAcucar      = 1   * quantidadeDeReceitas;
    int colheresOleo        = 2   * quantidadeDeReceitas;
    int gramasFermento      = 15  * quantidadeDeReceitas;
    
    int barrasChocolate     = 1   * quantidadeDeReceitas;
    int gramasQueijo        = 400 * quantidadeDeReceitas;
    int gramasSalsicha      = 200 * quantidadeDeReceitas;
    int gramasCalabreza     = 100 * quantidadeDeReceitas;
    
    int litrosRefri         = 2   * quantidadeDeReceitas;
    int latinhasCerveja     = 6   * quantidadeDeReceitas;
    
    // Monta as strings dinâmicamente de acordo com o valor do slider
    
    massaLabel.text = [[NSString alloc] initWithFormat:@"%d xícaras de farinha, %d xícaras de leite, %d xícaras de amido de milho, %d ovo(s), %d colher(es) de sal (chá), %d colher(es) de açúcar (chá), %d colher(es) de óleo (sopa), %d gramas de fermento biológico e palitos.", xicarasFarinha, xicarasLeite, xicarasAmidoMilho, ovos, colheresSal, colheresAcucar, colheresOleo, gramasFermento];
    
    recheiosLabel.text = [[NSString alloc] initWithFormat:@"%d barra(s) de chocolate de 180 gramas, %d gramas de queijo mussarela, %d gramas de salsicha e %d gramas de calabreza.", barrasChocolate, gramasQueijo, gramasSalsicha, gramasCalabreza];
    
    bebidasLabel.text = [[NSString alloc] initWithFormat:@"%d litros de refrigerante e %d latinhas de cerveja.", litrosRefri, latinhasCerveja];
}

//
// Navega utilizando o SegmentedControl
//
- (IBAction)segmentChanged:(id)sender {
    
    massaLabel.hidden = true;
    recheiosLabel.hidden = true;
    bebidasLabel.hidden = true;
    preparoLabel.hidden = true;
    
    switch([sender selectedSegmentIndex]) {
        case 0:
            massaLabel.hidden = false;
            break;
        case 1:
            recheiosLabel.hidden = false;
            break;
        case 2:
            bebidasLabel.hidden = false;
            break;
        case 3:
            preparoLabel.hidden = false;
            break;
    }
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    // Define o fundo de tela
    self.view.backgroundColor = [[UIColor alloc] 
                                 initWithPatternImage:[UIImage 
                                                       imageNamed:@"KrepsmakerBackground.png"]];
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
