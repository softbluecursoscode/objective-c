//
//  SaladaMistaViewController.h
//  SaladaMista
//
//  Created by André Milani on 7/2/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SaladaMistaViewController : UIViewController {
    UIImageView *resultIcon;
    UIImageView *resultDescription;
    UIButton *play;
    UIActivityIndicatorView *activity;
    Boolean eggEasterVar;
}

@property (nonatomic, retain) IBOutlet UIImageView *resultIcon;
@property (nonatomic, retain) IBOutlet UIImageView *resultDescription;
@property (nonatomic, retain) IBOutlet UIButton *play;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *activity;

- (IBAction)eggEaster;
- (IBAction)playGame;
- (void)playGameThreaded;

@end
