//
//  SaladaMistaViewController.m
//  SaladaMista
//
//  Created by André Milani on 7/2/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import "SaladaMistaViewController.h"

@implementation SaladaMistaViewController

@synthesize resultIcon;
@synthesize resultDescription;
@synthesize play;
@synthesize activity;

//
// Inicializa o jogo "batizado" se invocado pelo evento TouchUpOutside
//
- (IBAction)eggEaster {
    // Batiza o jogo
    eggEasterVar = TRUE;
    
    // Dá sequência normal ao jogo, invocando a IBAction playGame
    [self playGame];
}

//
// Inicializa o jogo
//
- (IBAction)playGame {
    
    // Trava o botão de jogar (esconde)
    [play setHidden:TRUE];
    
    // Limpa o gráfico de resultado
    resultIcon.image = [UIImage imageNamed:@"SaladaMistaIconeBlank.png"];
    resultDescription.image = [UIImage imageNamed:@"SaladaMistaLabelBlank.png"];
    
    // Delay de 3 segundos para criar suspense
    NSTimeInterval yourDelay = 3.0;
    [activity setHidden:FALSE];
    [activity startAnimating];

    // Define a função que será invocada após o delay de suspense
    [self performSelector:@selector(playGameThreaded) withObject:nil afterDelay:yourDelay];
}

//
// Apresenta o resultado, após o delay
//
- (void)playGameThreaded {

    // Reativa a posição e visualização dos botões
    [activity stopAnimating];
    [activity setHidden:TRUE];
    [play setHidden:FALSE];
    
    // Gera um número randômico  entre 0 e 3
    __block int randomNumber = arc4random() % 4;
    
    // Se a IBAction tiver sido chamada pelo evento TouchUpOutsite este IF será executado
    if(eggEasterVar)
    {
        eggEasterVar = FALSE;
        randomNumber = 3;
    }
    
    switch(randomNumber) {
        case 0:
            resultIcon.image = [UIImage imageNamed:@"SaladaMistaIconePera.png"];
            resultDescription.image = [UIImage imageNamed:@"SaladaMistaLabelPera.png"];
            break;
        case 1:
            resultIcon.image = [UIImage imageNamed:@"SaladaMistaIconeUva.png"];
            resultDescription.image = [UIImage imageNamed:@"SaladaMistaLabelUva.png"];
            break;
        case 2:
            resultIcon.image = [UIImage imageNamed:@"SaladaMistaIconeMaca.png"];
            resultDescription.image = [UIImage imageNamed:@"SaladaMistaLabelMaca.png"];
            break;
        case 3:
            resultIcon.image = [UIImage imageNamed:@"SaladaMistaIconeSaladaMista.png"];
            resultDescription.image = [UIImage imageNamed:@"SaladaMistaLabelSaladaMista.png"];
            break;
    }
}

- (void)dealloc
{
    [resultIcon release];
    [resultDescription release];
    [play release];
    [activity release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    // Define o fundo de tela
    self.view.backgroundColor = [[UIColor alloc] 
                                 initWithPatternImage:[UIImage 
                                                       imageNamed:@"SaladaMistaBackground.png"]];
    // Inicializa o eggEaster
    eggEasterVar = FALSE;
    
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    self.resultIcon = nil;
    self.resultDescription = nil;
    self.play = nil;
    self.activity = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
