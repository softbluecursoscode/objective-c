//
//  SaladaMistaAppDelegate.h
//  SaladaMista
//
//  Created by André Milani on 7/2/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SaladaMistaViewController;

@interface SaladaMistaAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet SaladaMistaViewController *viewController;

@end
