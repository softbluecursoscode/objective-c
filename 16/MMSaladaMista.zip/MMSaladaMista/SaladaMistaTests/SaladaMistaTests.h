//
//  SaladaMistaTests.h
//  SaladaMistaTests
//
//  Created by André Milani on 7/2/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface SaladaMistaTests : SenTestCase {
@private
    
}

@end
