//
//  SaladaMistaTests.m
//  SaladaMistaTests
//
//  Created by André Milani on 7/2/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import "SaladaMistaTests.h"


@implementation SaladaMistaTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SaladaMistaTests");
}

@end
