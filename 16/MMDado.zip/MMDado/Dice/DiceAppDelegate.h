//
//  DiceAppDelegate.h
//  Dice
//
//  Created by André Milani on 6/15/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DiceViewController;

@interface DiceAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet DiceViewController *viewController;

@end
