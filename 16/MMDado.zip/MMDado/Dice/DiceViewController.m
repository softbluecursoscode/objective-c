//
//  DiceViewController.m
//  Dice
//
//  Created by André Milani on 6/15/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#include <stdlib.h>

#import "DiceViewController.h"

@implementation DiceViewController

@synthesize minValueLabel;
@synthesize maxValueLabel;
@synthesize button;
@synthesize minValue;
@synthesize maxValue;
@synthesize resultLabel;

//
// Implementa o retorno do teclado
//
- (IBAction)textFieldDoneEditing:(id)sender {
    [sender resignFirstResponder];
}

//
// Implementa o toque no fundo da tela para fechar o teclado
//
- (IBAction)backgroundTap:(id)sender {
    [minValue resignFirstResponder];
    [maxValue resignFirstResponder];
}

//
// Gera um número randômico entre o mínimo e o máximo definido pelo usuário
//
- (IBAction)drawNumber:(id)sender {
    
    int minValueInt = minValue.text.intValue;
    int maxValueInt = maxValue.text.intValue;
    
    // Verifica se os valores não comprometem visualmente a aplicação
    if(maxValueInt > 99999999 || maxValueInt < -99999999 ||
       minValueInt > 99999999 || maxValueInt < -99999999) {
        UIAlertView *alert = [[UIAlertView alloc] 
                              initWithTitle:NSLocalizedString(@"Title alert", nil)
                              message:NSLocalizedString(@"Wrong dice", nil)
                              delegate:self 
                              cancelButtonTitle:NSLocalizedString(@"Button accept", nil) 
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
        resultLabel.text = @""; 
    }
    
    // Verifica se o valor máximo é maior que o valor mínimo
    else if(maxValueInt < minValueInt) {
        UIAlertView *alert = [[UIAlertView alloc] 
                              initWithTitle:NSLocalizedString(@"Title alert", nil)
                              message:NSLocalizedString(@"Minimum value tip", nil) 
                              delegate:self 
                              cancelButtonTitle:NSLocalizedString(@"Button accept", nil)
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
        resultLabel.text = @"";
    }
    
    // Verifica se os valores mínimo e máximo não são iguais
    else if(maxValueInt == minValueInt) {
        UIAlertView *alert = [[UIAlertView alloc] 
                              initWithTitle:NSLocalizedString(@"Title alert", nil)
                              message:NSLocalizedString(@"Maximum value tip", nil)
                              delegate:self 
                              cancelButtonTitle:NSLocalizedString(@"Button accept", nil)
                              otherButtonTitles:nil];
        [alert show];
        [alert release];
        resultLabel.text = @"";
    }
    
    // Gera um número randômico
    else {
        int result = minValueInt + (arc4random() % (maxValueInt - minValueInt + 1));
        NSString *resultText = [[NSString alloc] initWithFormat:@"%d", result];
        resultLabel.text = resultText;
        [resultText release];
    }
}

- (void)dealloc
{
    [minValueLabel release];
    [maxValueLabel release];
    [button release];
    [minValue release];
    [maxValue release];
    [resultLabel release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    // Define o fundo de tela
    self.view.backgroundColor = [[UIColor alloc] 
                                 initWithPatternImage:[UIImage 
                                                       imageNamed:@"DadoBackground_iPhone.png"]];
    
    // Define os textos das labels
    minValueLabel.text = NSLocalizedString(@"Minimum value", nil);
    maxValueLabel.text = NSLocalizedString(@"Maximum value", nil);
    
    // Define o título do botão que realiza a operação de jogar o dado
    [button setTitle: NSLocalizedString(@"Button title", nil) forState: UIControlStateNormal];
    
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    self.minValueLabel = nil;
    self.maxValueLabel = nil;
    self.button = nil;
    self.minValue = nil;
    self.maxValue = nil;
    self.resultLabel = nil;
    
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
