//
//  DiceViewController.h
//  Dice
//
//  Created by André Milani on 6/15/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiceViewController : UIViewController {
    UILabel *minValueLabel;
    UILabel *maxValueLabel;
    UIButton *button;
    UITextField *minValue;
    UITextField *maxValue;
    UILabel *resultLabel;
}

@property (nonatomic, retain) IBOutlet UILabel *minValueLabel;
@property (nonatomic, retain) IBOutlet UILabel *maxValueLabel;
@property (nonatomic, retain) IBOutlet UIButton *button;
@property (nonatomic, retain) IBOutlet UITextField *minValue;
@property (nonatomic, retain) IBOutlet UITextField *maxValue;
@property (nonatomic, retain) IBOutlet UILabel *resultLabel;

- (IBAction)textFieldDoneEditing:(id)sender;
- (IBAction)backgroundTap:(id)sender;
- (IBAction)drawNumber:(id)sender;

@end
