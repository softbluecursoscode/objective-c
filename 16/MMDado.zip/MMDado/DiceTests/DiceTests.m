//
//  DiceTests.m
//  DiceTests
//
//  Created by André Milani on 6/15/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import "DiceTests.h"


@implementation DiceTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in DiceTests");
}

@end
