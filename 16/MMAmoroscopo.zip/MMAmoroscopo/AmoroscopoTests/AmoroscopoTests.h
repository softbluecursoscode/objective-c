//
//  AmoroscopoTests.h
//  AmoroscopoTests
//
//  Created by André Milani on 6/26/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface AmoroscopoTests : SenTestCase {
@private
    
}

@end
