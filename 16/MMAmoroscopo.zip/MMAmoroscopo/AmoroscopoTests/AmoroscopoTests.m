//
//  AmoroscopoTests.m
//  AmoroscopoTests
//
//  Created by André Milani on 6/26/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import "AmoroscopoTests.h"


@implementation AmoroscopoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in AmoroscopoTests");
}

@end
