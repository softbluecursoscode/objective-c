//
//  AmoroscopoViewController.h
//  Amoroscopo
//
//  Created by André Milani on 6/26/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kUserComponent 0
#define kPartnerComponent 1

@interface AmoroscopoViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource> {
    UIPickerView *doublePicker;
    NSArray *signs;
    UIButton *button;
    UILabel *result;
}

@property (nonatomic, retain) IBOutlet UIPickerView *doublePicker;
@property (nonatomic, retain) NSArray *signs;
@property (nonatomic, retain) IBOutlet UIButton *button;
@property (nonatomic, retain) IBOutlet UILabel *result;

- (IBAction)calculateLoveSigns:(id)sender;

@end
