//
//  AmoroscopoViewController.m
//  Amoroscopo
//
//  Created by André Milani on 6/26/11.
//  Copyright 2011 Softblue. All rights reserved.
//

#import "AmoroscopoViewController.h"

@implementation AmoroscopoViewController

@synthesize doublePicker;
@synthesize signs;
@synthesize button;
@synthesize result;

//
// Calcula a compatibilidade dos signos
//
- (IBAction)calculateLoveSigns:(id)sender {
    
    // Captura o número da linha selecionada em cada componente do picker
    NSInteger userRow = [doublePicker selectedRowInComponent:kUserComponent];
    NSInteger partnerRow = [doublePicker selectedRowInComponent:kPartnerComponent];
    
    // Captura os nomes dos signos baseado nas linhas selecionadas nos componentes
    NSString *userSign = [signs objectAtIndex:userRow];
    NSString *partnerSign = [signs objectAtIndex:partnerRow];
    
    // Tabela fictícia de combinação entre signos (matriz)
    NSArray *signsMatches = [[NSArray alloc] initWithObjects:
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Aquário", nil),        @"5",@"4",@"5",@"2",@"5",@"1",@"3",@"2",@"5",@"3",@"4",@"2",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Peixes", nil),         @"4",@"5",@"1",@"3",@"3",@"5",@"2",@"4",@"2",@"5",@"2",@"4",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Áries", nil),          @"5",@"1",@"4",@"1",@"3",@"1",@"3",@"1",@"5",@"2",@"5",@"2",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Touro", nil),          @"2",@"3",@"1",@"4",@"1",@"4",@"3",@"5",@"2",@"5",@"1",@"5",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Gêmeos", nil),         @"5",@"3",@"3",@"1",@"4",@"1",@"5",@"1",@"3",@"1",@"5",@"2",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Câncer", nil),         @"1",@"5",@"1",@"4",@"1",@"4",@"5",@"5",@"2",@"5",@"1",@"5",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Leão", nil),           @"3",@"2",@"3",@"3",@"5",@"5",@"5",@"2",@"4",@"1",@"3",@"3",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Virgem", nil),         @"2",@"4",@"1",@"5",@"1",@"5",@"2",@"5",@"3",@"5",@"1",@"4",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Libra", nil),          @"5",@"2",@"5",@"2",@"3",@"2",@"4",@"3",@"3",@"1",@"3",@"2",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Escorpião", nil),      @"3",@"5",@"2",@"5",@"1",@"5",@"1",@"5",@"1",@"5",@"1",@"4",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Sagitário", nil),      @"4",@"2",@"5",@"1",@"5",@"1",@"3",@"1",@"3",@"1",@"5",@"1",nil],
        [[NSArray alloc] initWithObjects:NSLocalizedString(@"Capricórnio", nil),    @"2",@"4",@"2",@"5",@"2",@"5",@"3",@"4",@"2",@"4",@"1",@"4",nil],
        nil];
    
    NSInteger userSignMatrixIndex;
    NSInteger partnerSignMatrixIndex;
    
    // Localiza os índices de cada signo
    for(int x=0; x<[signsMatches count]; x++) {
        if(userSign == [[signsMatches objectAtIndex:x] objectAtIndex:0])
            userSignMatrixIndex = x;
        
        if(partnerSign == [[signsMatches objectAtIndex:x] objectAtIndex:0])
            partnerSignMatrixIndex = x;
    }
    
    // Captura o grau de combinação
    NSString *matchLevel = [[signsMatches objectAtIndex:userSignMatrixIndex] objectAtIndex:partnerSignMatrixIndex + 1];
    
    // Para criar um número mais "calculado" elabora um pouco mais o resultado
    int matchLevelAdvanced = [matchLevel intValue] * 20 - userSignMatrixIndex - partnerSignMatrixIndex;
    
    // Tratamento de números negativos
    if(matchLevelAdvanced < 0)
        matchLevelAdvanced = 0;
    
    // Apresenta o resultado na label
    result.text = [[NSString alloc] initWithFormat:@"%d%%", matchLevelAdvanced];
    
    [userSign release];
    [partnerSign release];
    [signsMatches release];
    [matchLevel release];
}

- (void)dealloc
{
    [doublePicker release];
    [signs release];
    [button release];
    [result release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    // Define o fundo de tela
    self.view.backgroundColor = [[UIColor alloc] 
                                 initWithPatternImage:[UIImage 
                                                       imageNamed:@"AmoroscopoBackground_iPhone.png"]];
    
    // Define o título do botão que processa a operação
    [button setTitle: NSLocalizedString(@"Processar", nil) forState: UIControlStateNormal];
    
    // Cria o array dos signos baseado em internacionalização
    NSArray *signsTemp = [[NSArray alloc] initWithObjects:
                          NSLocalizedString(@"Áries", nil), 
                          NSLocalizedString(@"Touro", nil), 
                          NSLocalizedString(@"Gêmeos", nil), 
                          NSLocalizedString(@"Câncer", nil), 
                          NSLocalizedString(@"Leão", nil), 
                          NSLocalizedString(@"Virgem", nil), 
                          NSLocalizedString(@"Libra", nil), 
                          NSLocalizedString(@"Escorpião", nil), 
                          NSLocalizedString(@"Sagitário", nil), 
                          NSLocalizedString(@"Capricórnio", nil), 
                          NSLocalizedString(@"Aquário", nil), 
                          NSLocalizedString(@"Peixes", nil), 
                          nil];
    self.signs = signsTemp;
    [signs release];
    
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    self.doublePicker = nil;
    self.button = nil;
    self.signs = nil;
    self.result = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Picker Data Source Methods

// Retorna o número de componentes do picker
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 2;
}

// Retorna o número de elementos em cada picker (como os componentes apresentam o mesmo conteúdo,
// não há a necessidade de um comando IF diferenciando os componentes do picker
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [self.signs count];
}

#pragma mark Picker Delegate Methods

// Retorna o título de cada linha do picker, igual para ambos os componentes novamente
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    return [self.signs objectAtIndex:row];
}

@end
