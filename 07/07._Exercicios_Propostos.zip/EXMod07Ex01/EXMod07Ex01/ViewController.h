//
//  ViewController.h
//  EXMod07Ex01
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
{
    NSDictionary *listValues;
    NSArray *listKeys;
}

@property (nonatomic, retain) NSDictionary *listValues;
@property (nonatomic, retain) NSArray *listKeys;

@end
