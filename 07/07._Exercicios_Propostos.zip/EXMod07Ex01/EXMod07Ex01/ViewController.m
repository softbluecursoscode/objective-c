//
//  ViewController.m
//  EXMod07Ex01
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize listValues;
@synthesize listKeys;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // Cria um acesso para um arquivo de propriedades
    NSString *filepath = [[NSBundle mainBundle] pathForResource:@"myCollection" ofType:@"plist"];
    
    // Cria e popula um NSDictionary a partir do arquivo de propriedades acessado na linha anterior
    NSDictionary *myDictionary = [[NSDictionary alloc] initWithContentsOfFile:filepath];
    listValues = myDictionary;
    
    // Ordena os objetos do array
    NSArray *myArray = [[listValues allKeys] sortedArrayUsingSelector:@selector(compare:)];
    listKeys = myArray;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark -
#pragma mark Table View Data Source / Delegate Methods

// Disponibiliza o array de chaves (índices) para o componente
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return listKeys;
}

// Retorna o número de seções existentes em uma tabela
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [listKeys count];
}

// Retorna o número de elementos existentes em uma seção específica da tabela
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *myKey = [listKeys objectAtIndex:section];
    NSArray *sectionTitle = [listValues objectForKey:myKey];
    return [sectionTitle count];
}

// Retorna a célula no índice passado como parâmetro
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Captura a seção que está sendo acessada
    NSInteger section = [indexPath section];
    
    // Captura a linha que está sendo criada (número)
    NSInteger row = [indexPath row];
    
    // Captura o nome da seção (índice)
    NSString *key = [listKeys objectAtIndex:section];
    
    // Captura a linha que está sendo criada (texto)
    NSArray *sectionTitle = [listValues objectForKey:key];
    
    // Cria a célula
    static NSString *cellId = @"IdentificadorQualquer";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    if(cell == nil) 
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    }
    
    // Define seu texto
    cell.textLabel.text = [sectionTitle objectAtIndex:row];
    
    return cell;
}

// Evento invocado na pós-seleção de uma célula
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Captura o nome da seção (índice)
    NSString *key = [listKeys objectAtIndex:[indexPath section]];
    
    // Captura a linha que está sendo criada (texto)
    NSArray *values = [listValues objectForKey:key];
    
    NSString *myMessage = [[NSString alloc] initWithFormat:@"%@", [values objectAtIndex:[indexPath row]]];
    
    //NSString *myMessage = @"";
    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Banco" 
                                                      message:myMessage 
                                                     delegate:nil 
                                            cancelButtonTitle:@"OK" 
                                            otherButtonTitles:nil];
    [myAlert show];
}

@end
