//
//  ViewController.m
//  SBTableViewIndexed
//
//  Created by Andre Milani on 17/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize musicalGroups;
@synthesize keysOfMusicalGroups;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

    NSString *filepath = [[NSBundle mainBundle] pathForResource:@"bandas" ofType:@"plist"];
    
    NSDictionary *myDictionary = [[NSDictionary alloc] initWithContentsOfFile:filepath];
    musicalGroups = myDictionary;
    
    // Ordena o array alfabeticamente
    
    NSArray *myArray = [[musicalGroups allKeys] sortedArrayUsingSelector:@selector(compare:)];

    keysOfMusicalGroups = myArray;
}

// Métodos que devem ser implementados do protocolo UITableViewDataSource

// Retorna o número de seções que a tabela gerencia

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return [keysOfMusicalGroups count];
}

// Retorna o número de linhas para cada seção de dados da tabela

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *myKey = [keysOfMusicalGroups objectAtIndex:section];
    NSArray *sectionList = [musicalGroups objectForKey:myKey];
    return [sectionList count];
}

// Retorna a célula preenchida com os dados quando o iOS solicita para exibí-la

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger section = [indexPath section];
    NSInteger row = [indexPath row];
    
    NSString *key = [keysOfMusicalGroups objectAtIndex:section];
    NSArray *title = [musicalGroups objectForKey:key];
    
    static NSString *cellId = @"Identificador";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    }
    
    cell.textLabel.text = [title objectAtIndex:row];
    
    return cell;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
