//
//  ViewController.h
//  SBTableViewIndexed
//
//  Created by Andre Milani on 17/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
{
    NSDictionary *musicalGroups;
    NSArray *keysOfMusicalGroups;
}

@property (nonatomic, retain) NSDictionary *musicalGroups;
@property (nonatomic, retain) NSArray *keysOfMusicalGroups;

@end
