//
//  ViewController.h
//  SBTableView
//
//  Created by Andre Milani on 17/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

// TableViews devem implementar os protocolos UITableViewDataSource e UITableViewDelegate

@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
{
    NSMutableArray *myDataSource;
}

@property (nonatomic, retain) NSMutableArray *myDataSource;

@end
