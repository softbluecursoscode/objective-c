//
//  ViewController.m
//  SBTableView
//
//  Created by Andre Milani on 17/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize myDataSource;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

    // Criação de 20 nomes de exemplo para utilizar no projeto
    
    NSMutableArray *myArray = [[NSMutableArray alloc] init];
    
    for(int i=0; i<20; i++)
    {
        NSString *tempNome = [[NSString alloc] initWithFormat:@"Nome %d", i];
        NSString *tempSobrenome = [[NSString alloc] initWithFormat:@"Sobrenome %d", i];
        NSArray *tempArray = [[NSArray alloc] initWithObjects:tempNome, tempSobrenome, nil];
        
        [myArray addObject:tempArray];
    }
    
    self.myDataSource = myArray;
}

// Métodos que devem ser implementados do protocolo UITableViewDataSource

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.myDataSource count];
}

- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *myId = @"Exemplo";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:myId];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier:myId];
        
        // Outros estilos de formatação
        
        // cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleSubtitle reuseIdentifier:myId];
        
        // cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleValue1 reuseIdentifier:myId];
        
        // cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleValue2 reuseIdentifier:myId];
    }
    
    NSArray *myObject = [myDataSource objectAtIndex:[indexPath row]];
    
    cell.textLabel.text = [myObject objectAtIndex:0];
    cell.detailTextLabel.text = [myObject objectAtIndex:1];
    
    UIImage *myIcon = [UIImage imageNamed:@"img_tableIconCube.png"];
    cell.imageView.image = myIcon;
    
    UIImage *myIconHighlighted = [UIImage imageNamed:@"img_tableIconCubeHighlighted"];
    cell.imageView.highlightedImage = myIconHighlighted;
    
    
    return cell;
}

// Métodos que devem ser implementados do protocolo UITableViewDelegate

- (NSIndexPath *) tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([indexPath row] == 0)
        return nil;
    else
        return indexPath;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *myMessage = [[NSString alloc] initWithFormat:@"%@", [myDataSource objectAtIndex:[indexPath row]]];
    
    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Informação"
                                                      message:myMessage
                                                     delegate:nil
                                            cancelButtonTitle:@"OK"
                                             otherButtonTitles:nil];
    [myAlert show];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
