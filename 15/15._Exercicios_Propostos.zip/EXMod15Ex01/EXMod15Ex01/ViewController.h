//
//  ViewController.h
//  EXMod15Ex01
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIPickerViewDelegate, UIPickerViewDataSource> 
{    
    UIPickerView *myPickerSingle;
    NSArray *myPickerData;
    UILabel *myLabel;
    UIButton *myButton;
}

@property (nonatomic, retain) IBOutlet UIPickerView *myPickerSingle;
@property (nonatomic, retain) NSArray *myPickerData;
@property (nonatomic, retain) IBOutlet UILabel *myLabel;
@property (nonatomic, retain) IBOutlet UIButton *myButton;

- (IBAction) show;

@end
