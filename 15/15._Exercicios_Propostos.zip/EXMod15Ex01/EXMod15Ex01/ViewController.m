//
//  ViewController.m
//  EXMod15Ex01
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize myPickerSingle;
@synthesize myPickerData;
@synthesize myLabel;
@synthesize myButton;

- (IBAction) show
{
    // Exibe o valor selecionado no picker na tela
    NSInteger myRow = [myPickerSingle selectedRowInComponent:0];
    NSString *myValue = [myPickerData objectAtIndex:myRow];
    NSString *myMessage = [[NSString alloc] initWithFormat:@"%@", myValue];
    
    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"UIAlertViewTitle", nil)
                                                      message:myMessage 
                                                     delegate:nil 
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [myAlert show];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // Cria um acesso para um arquivo de propriedades
    NSString *filepath = [[NSBundle mainBundle] pathForResource:@"myProperties" ofType:@"plist"];
    
    // Carrega o arquivo de propriedades como um NSDictionary
    NSDictionary *myDictionary;
    myDictionary = [[NSDictionary alloc] initWithContentsOfFile:filepath];
    
    // Lê o arquivo e organiza a lista em um array
    myPickerData = [[myDictionary objectForKey:@"Root"] sortedArrayUsingSelector:@selector(compare:)];

    // Definindo os textos da label e do botão
    myLabel.text = NSLocalizedString(@"LabelText", nil);
    [myButton setTitle: NSLocalizedString(@"ButtonTitle", nil) forState: UIControlStateNormal];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark -
#pragma mark Picker Data Source / Delegate Methods

// Função que retorna o número de componentes do picker
- (NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// Função que retorna o número de linhas de um componente do picker
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [myPickerData count];
}

// Função que retorna o valor de uma linha para apresentá-la no picker
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [myPickerData objectAtIndex:row];
}

@end
