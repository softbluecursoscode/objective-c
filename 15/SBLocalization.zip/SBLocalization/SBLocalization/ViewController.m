//
//  ViewController.m
//  SBLocalization
//
//  Created by Andre Milani on 31/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize myButton;
@synthesize myLabel;
@synthesize myTextField;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

    // Definindo o texto de uma label dinamicamente
    
    myLabel.text = NSLocalizedString(@"Texto da label", nil);
    
    // Definindo o texto do campo de texto
    
    [myTextField setPlaceholder: NSLocalizedString(@"Texto do textfield", nil)];
    
    // Definindo o texto do botão
    
    [myButton setTitle:NSLocalizedString(@"Texto do botao", nil) forState:UIControlStateNormal];
    
}

- (IBAction) doSomething
{
    UIAlertView *myAlert = [[UIAlertView alloc]
                  initWithTitle:NSLocalizedString(@"Titulo do alerta", nil)
                  message:NSLocalizedString(@"Mensagem do alerta", nil)
                  delegate:nil
                  cancelButtonTitle:NSLocalizedString(@"Botao do alerta", nil)
                  otherButtonTitles: nil];
    [myAlert show];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
