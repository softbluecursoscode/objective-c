//
//  EXMod08Ex01Tests.h
//  EXMod08Ex01Tests
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod08Ex01Tests : SenTestCase

@end
