//
//  AppDelegate.h
//  SBIntroObjectiveC
//
//  Created by Andre Milani on 14/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
