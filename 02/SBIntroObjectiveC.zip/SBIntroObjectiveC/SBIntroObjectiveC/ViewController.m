//
//  ViewController.m
//  SBIntroObjectiveC
//
//  Created by Andre Milani on 14/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

NSString *const myPINumber = @"3.14";

@interface ViewController ()

@end

@implementation ViewController

- (int) retornaDobro: (int) i
{
    return i * 2;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    NSString *myBuffer;
    myBuffer = @"";
    
    // OPERACOES MATEMATICAS
    /*
    int x = 4;
    int y = 3;
    float z = (float) x / (float) y;
     
    myBuffer = [[NSString alloc] initWithFormat:@"Resultado: %f", z];
     */
    
    // CONSTANTES
    /*
    float z = [myPINumber floatValue] * 2;
    
    myBuffer = [[NSString alloc] initWithFormat:@"Resultado: %f", z];
     */
    
    // FOR
    /*
    myBuffer = @"for: ";
    for(int i=0; i<5; i++)
    {
        NSString *newString = [[NSString alloc] initWithFormat:@"%d", i];
        myBuffer = [myBuffer stringByAppendingString:newString];
    }
     */
    
    // WHILE
    /*
    myBuffer = @"while: ";
    int i = 0;
    while(i < 5)
    {
        NSString *newString = [[NSString alloc] initWithFormat:@"%d", i];
        myBuffer = [myBuffer stringByAppendingString:newString];
        
        i++;
    }
     */
    
    // DO WHILE
    /*
    myBuffer = @"do while: ";
    int i = 10;
    do
    {
        NSString *newString = [[NSString alloc] initWithFormat:@"%d", i];
        myBuffer = [myBuffer stringByAppendingString:newString];
        
        i++;
    } while(i < 5);
     */
    
    // IF
    /*
    myBuffer = @"if: ";
    int i = 3;
    
    if(i > 5)
    {
        myBuffer =[myBuffer stringByAppendingString:@"i é maior que 5."];
    }
    else
    {
        myBuffer =[myBuffer stringByAppendingString:@"i é menor ou igual que 5."];
    }
     */
    
    // SHORT IF
    /*
    int i = 6;
    
    myBuffer = i == 5 ? @"i é 5" : @"i é outro valor";
    
    myBuffer = (i % 2 == 0) ? @"PAR" : @"IMPAR";
    */
    
    // SWITCH
    /*
    int i = 2;
    
    switch (i)
    {
        case 1:
            myBuffer = @"i entrou no primeiro case";
            break;
            
        case 2:
            myBuffer = @"i entrou no segundo case";
            break;
            
        case 3:
            myBuffer = @"i entrou no terceiro case";
            break;
            
        default:
            myBuffer = @"i não entrou em nenhum case";
            break;
    }
     */
    
    // COMO CRIAR E INVOCAR UMA FUNCAO
    /*
    int x = 5;
    int z = [self retornaDobro:x];
    myBuffer = [[NSString alloc] initWithFormat:@"Dobro de %d é %d", x, z];
     */
    
    // NSINTEGER
    /*
    NSInteger *myIntObject = 50;
    myBuffer = [[NSString alloc] initWithFormat:@"%d", myIntObject];
     */
    
    // NSNUMBER
    /*
    NSNumber *myNumberObject = [[NSNumber alloc] initWithDouble:10.35];
    myBuffer = [[NSString alloc] initWithFormat:@"%f", [myNumberObject floatValue]];
     */
    
    // NSARRAY
    /*
    NSArray *myArray = [[NSArray alloc] initWithObjects: @"Vermelho", @"Verde", @"Azul", nil];
    int pos = 1;
    
    NSString *myObject = [myArray objectAtIndex:pos];
    myBuffer = [[NSString alloc] initWithFormat:@"Na posição %d está o objeto %@", pos, myObject];
    
    int total = [myArray count];
    myBuffer = [[NSString alloc] initWithFormat:@"Meu array contém %d elementos", total];
     */
    
    // NSDictionary
    /*
    NSDictionary *myDictionary = [[NSDictionary alloc] initWithObjectsAndKeys:   @"1", @"One",
                                  @"2", @"Two",
                                  @"3", @"Three", nil];
    
    NSString *myKey = @"One";
    NSString *myObject = [myDictionary objectForKey:myKey];
    
    myBuffer = [[NSString alloc] initWithFormat:@"Chave %@ é do objeto %@", myKey, myObject];
     */
    
    // NSASSERT
    bool myCondition = 5 < 3;
    NSAssert(myCondition, @"Exception lançada");
    
    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Alerta"
                                                      message:myBuffer  delegate:nil cancelButtonTitle:@"OK"otherButtonTitles:nil];
    [myAlert show];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
