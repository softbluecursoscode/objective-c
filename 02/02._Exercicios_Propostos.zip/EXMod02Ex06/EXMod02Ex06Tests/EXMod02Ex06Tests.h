//
//  EXMod02Ex06Tests.h
//  EXMod02Ex06Tests
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod02Ex06Tests : SenTestCase

@end
