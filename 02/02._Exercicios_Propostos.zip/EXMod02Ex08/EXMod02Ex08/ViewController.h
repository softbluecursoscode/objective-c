//
//  ViewController.h
//  EXMod02Ex08
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

int minhaFuncaoIf(int x);

@end
