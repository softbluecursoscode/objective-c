//
//  EXMod02Ex03Tests.h
//  EXMod02Ex03Tests
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod02Ex03Tests : SenTestCase

@end
