//
//  EXMod02Ex03Tests.m
//  EXMod02Ex03Tests
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "EXMod02Ex03Tests.h"

@implementation EXMod02Ex03Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in EXMod02Ex03Tests");
}

@end
