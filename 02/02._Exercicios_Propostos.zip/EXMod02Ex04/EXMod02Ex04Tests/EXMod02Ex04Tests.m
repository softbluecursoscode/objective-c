//
//  EXMod02Ex04Tests.m
//  EXMod02Ex04Tests
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "EXMod02Ex04Tests.h"

@implementation EXMod02Ex04Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in EXMod02Ex04Tests");
}

@end
