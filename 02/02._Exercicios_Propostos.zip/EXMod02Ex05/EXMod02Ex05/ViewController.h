//
//  ViewController.h
//  EXMod02Ex05
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

float calculaMedia(float nota1, float nota2, float nota3, float peso1, float peso2, float peso3);

@end
