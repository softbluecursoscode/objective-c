//
//  ViewController.h
//  EXMod05Ex04
//
//  Created by Andre Milani on 2/5/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIActionSheetDelegate>
{
    UIButton *myButton;
    UILabel  *myLabel;
    UISlider *mySlider;
    UISwitch *mySwitch;
}

@property (nonatomic, retain) IBOutlet UIButton *myButton;
@property (nonatomic, retain) IBOutlet UILabel *myLabel;
@property (nonatomic, retain) IBOutlet UISlider *mySlider;
@property (nonatomic, retain) IBOutlet UISwitch *mySwitch;

- (IBAction) sliderChanged;
- (IBAction) processar;

@end
