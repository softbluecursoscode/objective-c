//
//  EXMod05Ex04Tests.h
//  EXMod05Ex04Tests
//
//  Created by Andre Milani on 2/5/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod05Ex04Tests : SenTestCase

@end
