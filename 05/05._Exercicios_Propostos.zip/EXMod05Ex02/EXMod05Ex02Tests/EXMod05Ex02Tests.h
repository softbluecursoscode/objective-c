//
//  EXMod05Ex02Tests.h
//  EXMod05Ex02Tests
//
//  Created by Andre Milani on 2/5/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod05Ex02Tests : SenTestCase

@end
