//
//  ViewController.h
//  EXMod05Ex02
//
//  Created by Andre Milani on 2/5/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UILabel *myLabel;
    UISlider *mySlider;
}

@property (nonatomic, retain) IBOutlet UILabel *myLabel;
@property (nonatomic, retain) IBOutlet UISlider *mySlider;

- (IBAction) processar;

@end
