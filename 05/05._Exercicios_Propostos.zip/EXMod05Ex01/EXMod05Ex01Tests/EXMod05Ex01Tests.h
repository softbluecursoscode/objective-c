//
//  EXMod05Ex01Tests.h
//  EXMod05Ex01Tests
//
//  Created by Andre Milani on 2/5/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod05Ex01Tests : SenTestCase

@end
