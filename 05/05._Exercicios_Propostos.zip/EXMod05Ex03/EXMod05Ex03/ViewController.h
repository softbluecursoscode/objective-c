//
//  ViewController.h
//  EXMod05Ex03
//
//  Created by Andre Milani on 2/5/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UILabel *myLabel;
    UISwitch *mySwitch;
}

@property (nonatomic, retain) IBOutlet UILabel *myLabel;
@property (nonatomic, retain) IBOutlet UISwitch *mySwitch;

- (IBAction) processar;

@end
