//
//  ViewController.h
//  SBForms
//
//  Created by Andre Milani on 15/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIActionSheetDelegate>
{
    // Propriedades da classe, utilizadas no formulário
    
    UIButton *buttonAlert;
    UITextField *textFieldSomeText;
    UILabel *labelSliderValue;
    UISlider *mySlider;
    UISwitch *mySwitch;
}

// Criação das IBOutlets e IBActions

@property (nonatomic, retain) IBOutlet UIButton *buttonAlert;
@property (nonatomic, retain) IBOutlet UITextField *textFieldSomeText;
@property (nonatomic, retain) IBOutlet UILabel *labelSliderValue;
@property (nonatomic, retain) IBOutlet UISlider *mySlider;
@property (nonatomic, retain) IBOutlet UISwitch *mySwitch;

- (IBAction) showAlert;
- (IBAction) showText;
- (IBAction) showSwitch;

- (IBAction) textFieldReturn:(id)sender;
- (IBAction) backgroundTouch;
- (IBAction) sliderValueChanged;
- (IBAction) askConfirmation;

@end
