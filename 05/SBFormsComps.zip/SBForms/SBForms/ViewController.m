//
//  ViewController.m
//  SBForms
//
//  Created by Andre Milani on 15/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize buttonAlert;
@synthesize textFieldSomeText;
@synthesize labelSliderValue;
@synthesize mySlider;
@synthesize mySwitch;

- (IBAction) showAlert
{
    UIAlertView *myAlert = [[UIAlertView alloc]
                            initWithTitle:@"Mensagem de alerta"
                            message:@"Meu primeiro alerta"
                            delegate:nil
                            cancelButtonTitle:@"OK"
                            otherButtonTitles:nil];
    [myAlert show];
}

- (IBAction) showText
{
    UIAlertView *myAlert = [[UIAlertView alloc]
                            initWithTitle:@"Mensagem de alerta"
                            message:textFieldSomeText.text
                            delegate:nil
                            cancelButtonTitle:@"OK"
                            otherButtonTitles:nil];
    [myAlert show];
}

// Tratamento do fechamento de teclado pelo uso da tecla RETURN

- (IBAction) textFieldReturn:(id)sender
{
    [sender resignFirstResponder];
}

// Tratamento do fechamento de teclado pelo toque no fundo da tela

- (IBAction) backgroundTouch
{
    [textFieldSomeText resignFirstResponder];
}

// Atualização de valor do slider na tela

- (IBAction) sliderValueChanged
{
    int sliderValue = (int)mySlider.value;
    NSString *newLabelText = [[NSString alloc] initWithFormat:@"%d", sliderValue];
    labelSliderValue.text = newLabelText;
}

- (IBAction) showSwitch
{
    NSString *myMessage;
    
    if(mySwitch.on)
    {
        myMessage = @"Switch ligado";
    }
    else
    {
        myMessage = @"Switch desligado";
    }
    
    UIAlertView *myAlert = [[UIAlertView alloc]
                            initWithTitle:@"Mensagem de alerta"
                            message:myMessage
                            delegate:nil
                            cancelButtonTitle:@"OK"
                            otherButtonTitles:nil];
    [myAlert show];
}

- (IBAction) askConfirmation
{
    UIActionSheet *myActionSheet = [[UIActionSheet alloc]
                                    initWithTitle:@"Deseja realizar esta operação?"
                                    delegate: self
                                    cancelButtonTitle:@"Não"
                                    destructiveButtonTitle:@"Sim" otherButtonTitles:nil];
    [myActionSheet showInView:self.view];
}

// Tratamento da caixa de mensagem de decisão

- (void)actionSheet: (UIActionSheet *)actionSheet didDismissWithButtonIndex: (NSInteger) buttonIndex
{
    NSString *myString;
    
    if(buttonIndex != [actionSheet cancelButtonIndex])
    {
        myString = @"Operação autorizada";
    }
    else
    {
        myString = @"Operação cancelada";
    }
    
    UIAlertView *myAlert = [[UIAlertView alloc]
                            initWithTitle:@"Mensagem de alerta"
                            message:myString
                            delegate:nil
                            cancelButtonTitle:@"OK"
                            otherButtonTitles:nil];
    [myAlert show];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
