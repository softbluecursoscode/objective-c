//
//  ViewController.h
//  SBCocoaTouch
//
//  Created by Andre Milani on 15/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    // Propriedades e atributos da classe ViewController
    
    UILabel *myLabel;
    UIButton *myButtonOne;
    UIButton *myButtonTwo;
}

// Transformação das propriedades da classe em IBOutlets

@property(nonatomic, retain) IBOutlet UILabel *myLabel;
@property(nonatomic, retain) IBOutlet UIButton *myButtonOne;
@property(nonatomic, retain) IBOutlet UIButton *myButtonTwo;

// Criação de uma IBAction

- (IBAction) executeSomeTask: (id) sender;

@end
