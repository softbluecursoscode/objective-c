//
//  ViewController.m
//  SBCocoaTouch
//
//  Created by Andre Milani on 15/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

// Sintetização das IBOutlets, para serem acessadas neste arquivo

@synthesize myLabel;
@synthesize myButtonOne;
@synthesize myButtonTwo;

// Definição do corpo de código da IBAction

- (IBAction) executeSomeTask:(id)sender
{
    NSString *quemInvocou = [sender titleForState:UIControlStateNormal];
    NSString *novoTexto = [[NSString alloc] initWithFormat:@"%@ utilizado", quemInvocou];
    myLabel.text = novoTexto;
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
