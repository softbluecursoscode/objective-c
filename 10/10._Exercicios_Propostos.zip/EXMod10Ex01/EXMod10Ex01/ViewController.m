//
//  ViewController.m
//  EXMod10Ex01
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize locationManager;
@synthesize localizacaoDeSaida;
@synthesize labelDistanciaPercorrida;
@synthesize labelAcao;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [locationManager startUpdatingLocation];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark -
#pragma mark CLLocationManagerDelegate Methods

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    if(localizacaoDeSaida == nil)
        self.localizacaoDeSaida = newLocation;
    
    CLLocationDistance distanciaOrigem = [newLocation distanceFromLocation:localizacaoDeSaida];
    NSString *distanciaString = [[NSString alloc] initWithFormat:@"Distância: %gm", distanciaOrigem];
    labelDistanciaPercorrida.text = distanciaString;
    
    CLLocationDistance distanciaAnterior = [oldLocation distanceFromLocation:localizacaoDeSaida];

    // Se estiver se afastando...
    if(distanciaOrigem > distanciaAnterior)
    {
        if(distanciaOrigem >= 20)
        {
            labelAcao.text = @"Saindo do círculo central";
        }
    }
    
    // Se estiver se aproximando...
    if(distanciaOrigem < distanciaAnterior)
    {
        if(distanciaOrigem < 20)
        {
            labelAcao.text = @"Retornando ao círculo central";
        }
    }
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSString *errorText = error.code == kCLErrorDenied ? @"Acesso negado" : @"Erro ao utilizar LocationManager";
    
    UIAlertView *myAlert = [[UIAlertView alloc] 
                            initWithTitle:@"Erro"
                            message:errorText
                            delegate:nil
                            cancelButtonTitle:@"OK"
                            otherButtonTitles:nil];
    [myAlert show];
}


@end
