//
//  ViewController.h
//  EXMod10Ex01
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController <CLLocationManagerDelegate> 
{    
    CLLocationManager *locationManager;
    CLLocation *localizacaoDeSaida;
    
    UILabel *labelDistanciaPercorrida;
    UILabel *labelAcao;
}

@property (nonatomic, retain) CLLocationManager *locationManager;
@property (nonatomic, retain) CLLocation *localizacaoDeSaida;
@property (nonatomic, retain) IBOutlet UILabel *labelDistanciaPercorrida;
@property (nonatomic, retain) IBOutlet UILabel *labelAcao;

@end
