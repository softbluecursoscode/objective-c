//
//  ViewController.h
//  SBCoreLocation
//
//  Created by Andre Milani on 30/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController <CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
    CLLocation *localizacaoDeSaida;
    
    UILabel *labelLatitude;
    UILabel *labelLongitude;
    UILabel *labelAltitude;
    UILabel *labelPrecisaoHorizontal;
    UILabel *labelPrecisaoVertical;
    UILabel *labelDistanciaPercorrida;
}

@property (nonatomic, retain) CLLocationManager *locationManager;
@property (nonatomic, retain) CLLocation *localizacaoDeSaida;

@property (nonatomic, retain) IBOutlet UILabel *labelLatitude;
@property (nonatomic, retain) IBOutlet UILabel *labelLongitude;
@property (nonatomic, retain) IBOutlet UILabel *labelAltitude;
@property (nonatomic, retain) IBOutlet UILabel *labelPrecisaoHorizontal;
@property (nonatomic, retain) IBOutlet UILabel *labelPrecisaoVertical;
@property (nonatomic, retain) IBOutlet UILabel *labelDistanciaPercorrida;

@end
