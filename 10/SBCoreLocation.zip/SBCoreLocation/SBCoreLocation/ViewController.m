//
//  ViewController.m
//  SBCoreLocation
//
//  Created by Andre Milani on 30/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize locationManager;
@synthesize localizacaoDeSaida;

@synthesize labelAltitude;
@synthesize labelDistanciaPercorrida;
@synthesize labelLatitude;
@synthesize labelLongitude;
@synthesize labelPrecisaoHorizontal;
@synthesize labelPrecisaoVertical;


// Método do protocolo CLLocationManagerDelegate que gerencia as atualizações do GPS

- (void) locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *newLocation = [locations lastObject];
    
    if(localizacaoDeSaida == nil)
    {
        localizacaoDeSaida = newLocation;
    }
    
    labelLatitude.text = [[NSString alloc] initWithFormat:@"%g\u00B0",
                          newLocation.coordinate.latitude];
    
    labelLongitude.text = [[NSString alloc] initWithFormat:@"%g\u00B0",
                          newLocation.coordinate.longitude];
    
    labelAltitude.text = [[NSString alloc] initWithFormat:@"%g m",
                          newLocation.coordinate.latitude];
    
    labelPrecisaoHorizontal.text = [[NSString alloc] initWithFormat:@"%g m",
                          newLocation.horizontalAccuracy];
    
    labelPrecisaoVertical.text = [[NSString alloc] initWithFormat:@"%g m",
                                    newLocation.verticalAccuracy];
    
    CLLocationDistance distancia = [newLocation distanceFromLocation:localizacaoDeSaida];
    
    labelDistanciaPercorrida.text = [[NSString alloc]
                                     initWithFormat:@"%g m", distancia];
}

- (void) locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSString *errorText = (error.code == kCLErrorDenied) ? @"Acesso negado" : @"Erro ao utilizar o Location Manager";
    
    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Erro"
                                                      message: errorText
                                                     delegate:nil
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles: nil];
    [myAlert show];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy =  kCLLocationAccuracyBest;
    [locationManager startUpdatingLocation];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
