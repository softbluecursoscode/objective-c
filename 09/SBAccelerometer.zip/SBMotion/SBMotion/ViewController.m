//
//  ViewController.m
//  SBMotion
//
//  Created by Andre Milani on 19/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize motionManager;
@synthesize labelAccelerometerX;
@synthesize labelAccelerometerY;
@synthesize labelAccelerometerZ;
@synthesize labelGyroscopeX;
@synthesize labelGyroscopeY;
@synthesize labelGyroscopeZ;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

    self.motionManager = [[CMMotionManager alloc] init];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    // Inicialização e tratamento do acelerômetro
    
    if(motionManager.accelerometerAvailable)
    {
        motionManager.accelerometerUpdateInterval = 1.0 / 10.0;
        
        [motionManager
         startAccelerometerUpdatesToQueue:queue
         withHandler:^(CMAccelerometerData *accelerometerData, NSError *error) {
             
             if(error) {
                 UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Erro"
                     message:@"Falha ao iniciar o acelerômetro"
                     delegate:nil
                     cancelButtonTitle:@"OK"
                     otherButtonTitles:nil];
                 
                 [myAlert show];
             }
             else
             {
                 [labelAccelerometerX
                  performSelectorOnMainThread:@selector(setText:)
                  withObject:
                            [NSString stringWithFormat:@"%+.2f", accelerometerData.acceleration.x]
                  waitUntilDone:TRUE];
                 
                 [labelAccelerometerY
                  performSelectorOnMainThread:@selector(setText:)
                  withObject:
                  [NSString stringWithFormat:@"%+.2f", accelerometerData.acceleration.y]
                  waitUntilDone:TRUE];
                 
                 [labelAccelerometerZ
                  performSelectorOnMainThread:@selector(setText:)
                  withObject:
                  [NSString stringWithFormat:@"%+.2f", accelerometerData.acceleration.z]
                  waitUntilDone:TRUE];
             }
         }];
    }
    else
    {
        UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Erro"
                                               message:@"Sem acelerômetro"
                                               delegate:nil
                                cancelButtonTitle:@"OK"
                                 otherButtonTitles:nil];
        [myAlert show];
        
    }
    
    // Inicialização e tratamento do giroscópio
    
    if(motionManager.gyroAvailable)
    {
        motionManager.gyroUpdateInterval = 1.0 / 10.0;
        
        [motionManager startGyroUpdatesToQueue:queue
         withHandler:^(CMGyroData *gyroData, NSError *error) {
             
             if(error)
             {
                 UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Erro"
                                                                   message:@"Falha ao iniciar o giroscópio"
                                                    delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                         otherButtonTitles:nil];
                 
                 [myAlert show];
             }
             else
             {
                 [labelGyroscopeX
                  performSelectorOnMainThread:@selector(setText:) withObject:[NSString stringWithFormat:@"%+.2f", gyroData.rotationRate.x]
                  waitUntilDone:TRUE];
                 
                 [labelGyroscopeY
                  performSelectorOnMainThread:@selector(setText:) withObject:[NSString stringWithFormat:@"%+.2f", gyroData.rotationRate.y]
                  waitUntilDone:TRUE];
                 
                 [labelGyroscopeZ
                  performSelectorOnMainThread:@selector(setText:) withObject:[NSString stringWithFormat:@"%+.2f", gyroData.rotationRate.z]
                  waitUntilDone:TRUE];
             }
             
         }];
    }
    else
    {
        UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Erro"
                                                          message:@"Sem giroscópio"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [myAlert show];
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
