//
//  ViewController.h
//  SBMotion
//
//  Created by Andre Milani on 19/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface ViewController : UIViewController
{
    CMMotionManager *motionManager;
    
    UILabel *labelAccelerometerX;
    UILabel *labelAccelerometerY;
    UILabel *labelAccelerometerZ;
    
    UILabel *labelGyroscopeX;
    UILabel *labelGyroscopeY;
    UILabel *labelGyroscopeZ;
}

@property (nonatomic, retain) CMMotionManager *motionManager;

@property (nonatomic, retain) IBOutlet UILabel *labelAccelerometerX;
@property (nonatomic, retain) IBOutlet UILabel *labelAccelerometerY;
@property (nonatomic, retain) IBOutlet UILabel *labelAccelerometerZ;

@property (nonatomic, retain) IBOutlet UILabel *labelGyroscopeX;
@property (nonatomic, retain) IBOutlet UILabel *labelGyroscopeY;
@property (nonatomic, retain) IBOutlet UILabel *labelGyroscopeZ;

@end
