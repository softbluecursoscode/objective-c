//
//  ViewController.m
//  EXMod09Ex02
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize motionManager;
@synthesize labelGyroscopeX;
@synthesize labelGyroscopeY;
@synthesize labelGyroscopeZ;
@synthesize labelGyroscopeMaxX;
@synthesize labelGyroscopeMaxY;
@synthesize labelGyroscopeMaxZ;

- (IBAction) resetar
{
    labelGyroscopeMaxX.text = @"0";
    labelGyroscopeMaxY.text = @"0";
    labelGyroscopeMaxZ.text = @"0";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.motionManager = [[CMMotionManager alloc] init];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    __block float maxX = 0;
    __block float maxY = 0;
    __block float maxZ = 0;
    
    if(motionManager.gyroAvailable)
    {
        motionManager.gyroUpdateInterval = 1.0 / 10.0;
        [motionManager 
         startGyroUpdatesToQueue:queue 
         withHandler:^(CMGyroData *gyroData, NSError *error) {
             
             if(error) {
                 UIAlertView *myAlert = [[UIAlertView alloc] 
                                         initWithTitle:@"Erro" 
                                         message:@"Erro ao iniciar o Giroscópio" 
                                         delegate:nil
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
                 [myAlert show];
             }
             else {
                 [labelGyroscopeX performSelectorOnMainThread:@selector(setText:)
                                                   withObject:[NSString stringWithFormat:@"x: %+.2f", gyroData.rotationRate.x]
                                                waitUntilDone:TRUE];
                 [labelGyroscopeY performSelectorOnMainThread:@selector(setText:)
                                                   withObject:[NSString stringWithFormat:@"y: %+.2f", gyroData.rotationRate.y]
                                                waitUntilDone:TRUE];
                 [labelGyroscopeZ performSelectorOnMainThread:@selector(setText:)
                                                   withObject:[NSString stringWithFormat:@"z: %+.2f", gyroData.rotationRate.z]
                                                waitUntilDone:TRUE];
                 
                 if(gyroData.rotationRate.x > maxX)
                 {
                     maxX = gyroData.rotationRate.x;
                     [labelGyroscopeMaxX performSelectorOnMainThread:@selector(setText:)
                                                          withObject:[NSString stringWithFormat:@"%+.2f", maxX]
                                                       waitUntilDone:TRUE];
                 }
                 
                 if(gyroData.rotationRate.y > maxY)
                 {
                     maxY = gyroData.rotationRate.y;
                     [labelGyroscopeMaxY performSelectorOnMainThread:@selector(setText:)
                                                          withObject:[NSString stringWithFormat:@"%+.2f", maxY]
                                                       waitUntilDone:TRUE];
                 }
                 
                 if(gyroData.rotationRate.z > maxZ)
                 {
                     maxZ = gyroData.rotationRate.z;
                     [labelGyroscopeMaxZ performSelectorOnMainThread:@selector(setText:)
                                                          withObject:[NSString stringWithFormat:@"%+.2f", maxZ]
                                                       waitUntilDone:TRUE];
                 }
             }
         }];
    }
    else {
        UIAlertView *myAlert = [[UIAlertView alloc] 
                                initWithTitle:@"Erro" 
                                message:@"Este dispositivo não possui Giroscópio" 
                                delegate:nil
                                cancelButtonTitle:@"OK"
                                otherButtonTitles:nil];
        [myAlert show];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
