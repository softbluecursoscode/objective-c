//
//  ViewController.h
//  EXMod09Ex02
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface ViewController : UIViewController
{
    CMMotionManager *motionManager;
    
    UILabel *labelGyroscopeX;
    UILabel *labelGyroscopeY;
    UILabel *labelGyroscopeZ;
    UILabel *labelGyroscopeMaxX;
    UILabel *labelGyroscopeMaxY;
    UILabel *labelGyroscopeMaxZ;
}

@property (nonatomic, retain) CMMotionManager *motionManager;

@property (nonatomic, retain) IBOutlet UILabel *labelGyroscopeX;
@property (nonatomic, retain) IBOutlet UILabel *labelGyroscopeY;
@property (nonatomic, retain) IBOutlet UILabel *labelGyroscopeZ;
@property (nonatomic, retain) IBOutlet UILabel *labelGyroscopeMaxX;
@property (nonatomic, retain) IBOutlet UILabel *labelGyroscopeMaxY;
@property (nonatomic, retain) IBOutlet UILabel *labelGyroscopeMaxZ;

- (IBAction) resetar;

@end
