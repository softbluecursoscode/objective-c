//
//  ViewController.h
//  EXMod09Ex01
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface ViewController : UIViewController
{
    CMMotionManager *motionManager;
    
    UILabel *labelAlert;
    UILabel *labelAccelerometerX;
    UILabel *labelAccelerometerY;
    UILabel *labelAccelerometerZ;
}

@property (nonatomic, retain) CMMotionManager *motionManager;

@property (nonatomic, retain) IBOutlet UILabel *labelAlert;
@property (nonatomic, retain) IBOutlet UILabel *labelAccelerometerX;
@property (nonatomic, retain) IBOutlet UILabel *labelAccelerometerY;
@property (nonatomic, retain) IBOutlet UILabel *labelAccelerometerZ;

- (IBAction) reset;

@end
