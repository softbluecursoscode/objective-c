//
//  ViewController.m
//  EXMod09Ex01
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

@synthesize motionManager;
@synthesize labelAlert;
@synthesize labelAccelerometerX;
@synthesize labelAccelerometerY;
@synthesize labelAccelerometerZ;

- (IBAction) reset
{
    labelAlert.text = @"Eixo Y não atingiu 95%";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.motionManager = [[CMMotionManager alloc] init];
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    if(motionManager.accelerometerAvailable)
    {
        motionManager.accelerometerUpdateInterval = 1.0 / 10.0;
        [motionManager 
         startAccelerometerUpdatesToQueue:queue 
         withHandler:^(CMAccelerometerData *accelerometerData, NSError *error) {
             
             if(error) {
                 UIAlertView *myAlert = [[UIAlertView alloc] 
                                         initWithTitle:@"Erro" 
                                         message:@"Erro ao iniciar o Acelerometro" 
                                         delegate:nil
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
                 [myAlert show];
             }
             else {
                 [labelAccelerometerX performSelectorOnMainThread:@selector(setText:)
                                                       withObject:[NSString stringWithFormat:@"x: %+.2f", accelerometerData.acceleration.x]
                                                    waitUntilDone:TRUE];
                 [labelAccelerometerY performSelectorOnMainThread:@selector(setText:)
                                                       withObject:[NSString stringWithFormat:@"y: %+.2f", accelerometerData.acceleration.y]
                                                    waitUntilDone:TRUE];
                 [labelAccelerometerZ performSelectorOnMainThread:@selector(setText:)
                                                       withObject:[NSString stringWithFormat:@"z: %+.2f", accelerometerData.acceleration.z]
                                                    waitUntilDone:TRUE];
                 
                 if(accelerometerData.acceleration.y > 0.95 || accelerometerData.acceleration.y < -0.95)
                 {
                     [labelAlert performSelectorOnMainThread:@selector(setText:)
                                                           withObject:[NSString stringWithFormat:@"ATINGIDO"]
                                                        waitUntilDone:TRUE];
                 }
             }
         }];
    }
    else {
        UIAlertView *myAlert = [[UIAlertView alloc] 
                                initWithTitle:@"Erro" 
                                message:@"Este dispositivo não possui Acelerômetro" 
                                delegate:nil
                                cancelButtonTitle:@"OK"
                                otherButtonTitles:nil];
        [myAlert show];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
