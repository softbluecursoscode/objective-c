//
//  EXMod09Ex01Tests.m
//  EXMod09Ex01Tests
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "EXMod09Ex01Tests.h"

@implementation EXMod09Ex01Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in EXMod09Ex01Tests");
}

@end
