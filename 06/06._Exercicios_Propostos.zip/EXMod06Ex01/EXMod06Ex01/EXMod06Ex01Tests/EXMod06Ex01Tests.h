//
//  EXMod06Ex01Tests.h
//  EXMod06Ex01Tests
//
//  Created by Andre Milani on 2/8/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod06Ex01Tests : SenTestCase

@end
