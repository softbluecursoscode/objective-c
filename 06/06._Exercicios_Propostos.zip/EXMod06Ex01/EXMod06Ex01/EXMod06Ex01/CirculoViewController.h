//
//  CirculoViewController.h
//  EXMod06Ex01
//
//  Created by Andre Milani on 2/8/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CirculoViewController : UIViewController

- (IBAction) show;

@end
