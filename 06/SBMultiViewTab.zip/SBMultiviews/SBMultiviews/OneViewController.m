//
//  OneViewController.m
//  SBMultiviews
//
//  Created by Andre Milani on 15/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "OneViewController.h"
#import "AppDelegate.h"

@interface OneViewController ()

@end

@implementation OneViewController

@synthesize myTextField;

// Tratamento de teclado já com compartilhamento de informação com outra classe

- (IBAction) returnKeyboard
{
    AppDelegate *myAppDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    
    myAppDelegate.sharedString = myTextField.text;
    
    [myTextField resignFirstResponder];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
