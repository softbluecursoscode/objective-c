//
//  StarViewController.h
//  SBMultiviews
//
//  Created by Andre Milani on 15/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StarViewController : UIViewController
{
    UILabel *myLabel;
}

@property (nonatomic, retain) IBOutlet UILabel *myLabel;

- (IBAction) updateSecondScreen;

@end
