//
//  StarViewController.m
//  SBMultiviews
//
//  Created by Andre Milani on 15/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "StarViewController.h"
#import "AppDelegate.h"

@interface StarViewController ()

@end

@implementation StarViewController

@synthesize myLabel;

// Leitura de informação compartilhada com outra classe

- (IBAction) updateSecondScreen
{
    AppDelegate *myAppDelegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    
    myLabel.text = myAppDelegate.sharedString;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
