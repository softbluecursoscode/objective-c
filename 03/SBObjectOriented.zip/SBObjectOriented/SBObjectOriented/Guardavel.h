//
//  Guardavel.h
//  SBObjectOriented
//
//  Created by Andre Milani on 14/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol Guardavel

- (NSString *) guardar;

@end
