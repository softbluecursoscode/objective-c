//
//  Carro.m
//  SBObjectOriented
//
//  Created by Andre Milani on 14/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "Carro.h"

@implementation Carro

-(void) setVelocidade: (int)novaVelocidade
{
    velocidade = novaVelocidade;
}

-(void) setCor: (NSString *)novaCor
{
    cor = novaCor;
}

-(int) getVelocidade
{
    return velocidade;
}

-(NSString *) getCor
{
    return cor;
}

-(void) acelerar
{
    if(velocidade == 110)
    {
        return;
    }
    
    velocidade++;
}

-(void) frear
{
    if(velocidade == 0)
    {
        return;
    }
    
    velocidade--;
}

-(Carro *) initWithCorAndVelocidade: (NSString *) c velocidade: (int) v
{
    self = [super init];
    
    [self setCor:c];
    [self setVelocidade:v];
    
    return self;
}

@end
