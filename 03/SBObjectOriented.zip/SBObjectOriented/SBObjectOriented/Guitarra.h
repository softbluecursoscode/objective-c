//
//  Guitarra.h
//  SBObjectOriented
//
//  Created by Andre Milani on 14/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InstrumentoMusical.h"

@interface Guitarra : InstrumentoMusical
{
    @public
    int numeroDeCordas;
}

- (Guitarra *) initWithIsPercussao: (bool) p volume:(int) v numeroDeCordas: (int) n;

- (NSString *) plugarAmplificador;

@end
