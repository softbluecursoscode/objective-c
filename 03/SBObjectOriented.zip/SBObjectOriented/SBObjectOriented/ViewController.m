//
//  ViewController.m
//  SBObjectOriented
//
//  Created by Andre Milani on 14/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    NSString *myBuffer;
    
    Guitarra *myGuitarra = [[Guitarra alloc] initWithIsPercussao:FALSE volume:100 numeroDeCordas:6];
    
    myBuffer = [[NSString alloc] initWithFormat:@"Número de cordas: %d", myGuitarra->numeroDeCordas];
    
    myBuffer = [myGuitarra tocar];
    
    myBuffer = [myGuitarra guardar];
    
    
    
    
    /*
    Carro *myCar = [[Carro alloc] initWithCorAndVelocidade:@"Vermelha" velocidade:98];
    
    [myCar acelerar];
    [myCar acelerar];
    [myCar acelerar];
    [myCar frear];
    
    myBuffer = [[NSString alloc] initWithFormat:@"Velocidade atual: %d", [myCar getVelocidade]];
     */
    
    UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Alerta"
                            message:myBuffer
                            delegate:nil
                            cancelButtonTitle:@"OK"
                            otherButtonTitles: nil];
    [myAlert show];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
