//
//  InstrumentoMusical.h
//  SBObjectOriented
//
//  Created by Andre Milani on 14/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Guardavel.h"

@interface InstrumentoMusical : NSObject <Guardavel> {
    bool isPercussao;
    int volume;
}

- (InstrumentoMusical *) initWithIsPercussao: (bool) p volume: (int) v;

- (NSString *) tocar;

@end
