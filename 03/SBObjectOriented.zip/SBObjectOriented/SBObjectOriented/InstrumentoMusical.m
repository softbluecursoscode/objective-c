//
//  InstrumentoMusical.m
//  SBObjectOriented
//
//  Created by Andre Milani on 14/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "InstrumentoMusical.h"

@implementation InstrumentoMusical

- (InstrumentoMusical *) initWithIsPercussao: (bool) p volume: (int) v
{
    self = [super init];
    
    self->isPercussao = p;
    self->volume = v;
    
    return self;
}

- (NSString *) tocar
{
    return @"Som de instrumento";
}

- (NSString *) guardar
{
    return @"Guardando instrumento genérico";
}

@end
