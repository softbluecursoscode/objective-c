//
//  Guitarra.m
//  SBObjectOriented
//
//  Created by Andre Milani on 14/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "Guitarra.h"

@implementation Guitarra

- (Guitarra *) initWithIsPercussao: (bool) p volume:(int) v numeroDeCordas: (int) n
{
    self = [super initWithIsPercussao:p volume:v];
    
    self->numeroDeCordas = n;
    
    return self;
}

- (NSString *) tocar
{
    return @"Som de guitarra";
}

- (NSString *) guardar
{
    return @"Guitarra guardada em case próprio de guitarra";
}

- (NSString *) plugarAmplificador
{
    return @"Plugado";
}



@end
