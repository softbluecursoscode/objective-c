//
//  Quadrado.m
//  EXMod03Ex01
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "Quadrado.h"

@implementation Quadrado

- (float) calculoDaArea
{
    return comprimento * altura;
}

- (id) initWithComprimento: (float) c altura: (float) a
{
    self->comprimento = c;
    self->altura = a;
    return self;
}

@end
