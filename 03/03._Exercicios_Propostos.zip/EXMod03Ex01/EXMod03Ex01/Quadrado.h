//
//  Quadrado.h
//  EXMod03Ex01
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FormaGeometrica.h"

@interface Quadrado : NSObject <FormaGeometrica>
{
    float comprimento;
    float altura;
}

- (id) initWithComprimento: (float) c altura: (float) a;

@end
