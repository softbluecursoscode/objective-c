//
//  Circulo.m
//  EXMod03Ex01
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "Circulo.h"

@implementation Circulo

- (float) calculoDaArea
{
    return 3.14 * (raio * raio);
}

- (id) initWithRaio: (float) r
{
    self->raio = r;
    
    return self;
}

@end
