//
//  Losangulo.h
//  EXMod03Ex01
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FormaGeometrica.h"

@interface Losangulo : NSObject <FormaGeometrica>
{
    float diagonalMaior;
    float diagonalMenor;
}

- (id) initWithDiagonalMaior: (float) dMaior diagonalMenor: (float) dMenor;

@end
