//
//  Losangulo.m
//  EXMod03Ex01
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "Losangulo.h"

@implementation Losangulo

- (float) calculoDaArea
{
    return (diagonalMaior * diagonalMenor) / 2;
}

- (id) initWithDiagonalMaior: (float) dMaior diagonalMenor: (float) dMenor
{
    self->diagonalMaior = dMaior;
    self->diagonalMenor = dMenor;
    return self;
}

@end
