//
//  ViewController.h
//  EXMod03Ex01
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Circulo.h"
#import "Losangulo.h"
#import "Quadrado.h"

@interface ViewController : UIViewController

@end
