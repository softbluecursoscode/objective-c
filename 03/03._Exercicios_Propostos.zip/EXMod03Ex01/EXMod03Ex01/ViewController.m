//
//  ViewController.m
//  EXMod03Ex01
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // Para acessar as classes é necessário importá-las no ViewController.h
    
    Circulo *circulo = [[Circulo alloc] initWithRaio:2.5];
    Losangulo *losangulo = [[Losangulo alloc] initWithDiagonalMaior:3.0 diagonalMenor:1.5];
    Quadrado *quadrado = [[Quadrado alloc] initWithComprimento:4.0 altura:2.0];
    
    float ac = [circulo calculoDaArea];
    float al = [losangulo calculoDaArea];
    float aq = [quadrado calculoDaArea];
    
    // O caracter de escape "\n" é utilizado para quebrar linha
    
    NSString *buffer = [[NSString alloc] initWithFormat:@"Área do círculo: %f\nÁrea do losângulo: %f\nÁrea do quadrado: %f", ac, al, aq];
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Buffer"
                                                        message:buffer
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    [alertView show];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
