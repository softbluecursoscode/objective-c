//
//  EXMod03Ex02Tests.h
//  EXMod03Ex02Tests
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface EXMod03Ex02Tests : SenTestCase

@end
