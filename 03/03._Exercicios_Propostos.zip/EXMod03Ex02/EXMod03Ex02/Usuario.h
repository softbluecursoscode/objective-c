//
//  Usuario.h
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Pessoa.h"

/**
 * A classe USUARIO extende de PESSOA, e tem um atributo próprio que FUNCIONARIO
 * não tem: o número de locações já realizadas por esta pessoa. Para interagir
 * com este dado, foram criados os métodos set e get deste atributo, uma vez
 * que o atributo foi criado como PRIVATE para evitar o acesso externo ao mesmo.
 * */ 

@interface Usuario : Pessoa <ShowInfo>
{
    @private
    int numeroDeLocacoes;
}

- (id) initWithNome: (NSString *) n telefone: (NSString *) t endereco: (NSString *) e numeroDeLocacoes: (int) ndl;

- (void) setNumeroDeLocacoes: (int) ndl;

- (int) getNumeroDeLocacoes;

@end
