//
//  DVD.h
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Produto.h"

/**
 * Classe DVD, extende de PRODUTO, e é complementada pelas informações que só
 * existem para os DVDs. Como a classe PRODUTO possui um método de exibição de
 * dados é recomendado sobreescrevê-lo (showInfoProduto)
 * */  

@interface DVD : Produto
{
    @private
    NSString *titulo;
}

- (id) initWithTitulo: (NSString *) t estilo: (NSString *) e codigo: (NSString *) c;

@end
