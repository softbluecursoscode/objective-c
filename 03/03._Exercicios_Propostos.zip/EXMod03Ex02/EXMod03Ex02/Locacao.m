//
//  Locacao.m
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "Locacao.h"

@implementation Locacao

- (id) initWithFuncionario: (Funcionario *) f usuario: (Usuario *) u produto: (Produto *) p
{
    self->funcionario = f;
    self->usuario = u;
    self->produto = p;
    
    // Atualiza o número de locações do usuário
    int locacoesDoUsuario = [self->usuario getNumeroDeLocacoes];
    [self->usuario setNumeroDeLocacoes:locacoesDoUsuario + 1];
    
    return self;
}

- (NSString *) showInfo
{
    return [[NSString alloc] initWithFormat:@"Info de Locacao: \n%@ \n%@ \n%@",
            [self->funcionario showInfo],
            [self->usuario showInfo],
            [self->produto showInfo]];
}

@end
