//
//  Usuario.m
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "Usuario.h"

@implementation Usuario

// Novo construtor com o atributo numeroDeLocacoes
- (id) initWithNome: (NSString *) n telefone: (NSString *) t endereco: (NSString *) e numeroDeLocacoes: (int) ndl
{
    // Utilizando o construtor da super-classe para os atributos existentes nela
    self = [super initWithNome:n telefone:t endereco:e];
    
    self->numeroDeLocacoes = ndl;
    
    return self;
}

- (void) setNumeroDeLocacoes: (int) ndl
{
    self->numeroDeLocacoes = ndl;
}

- (int) getNumeroDeLocacoes
{
    return self->numeroDeLocacoes;
}

// Sobreescrita do método definido na classe PESSOA
- (NSString *) showInfo
{
    return [[NSString alloc] initWithFormat:@"Info de usuário: %@ %@ %@ %d",
            self->nome,
            self->telefone,
            self->endereco,
            self->numeroDeLocacoes];
}

@end
