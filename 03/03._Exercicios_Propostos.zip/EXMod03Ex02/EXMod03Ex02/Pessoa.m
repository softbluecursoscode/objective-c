//
//  Pessoa.m
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "Pessoa.h"

@implementation Pessoa

- (id) initWithNome: (NSString *) n telefone: (NSString *) t endereco: (NSString *) e
{
    self->nome = n;
    self->telefone = t;
    self->endereco = e;
    
    return self;
}

- (NSString *) getNome
{
    return self->nome;
}

// Nesta classe não é necessário implementá-lo, mas sim, nas que herdem
- (NSString *) showInfo
{
    return @"";
}

@end
