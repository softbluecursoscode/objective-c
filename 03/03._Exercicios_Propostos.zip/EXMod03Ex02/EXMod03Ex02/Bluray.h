//
//  Bluray.h
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Produto.h"

/**
 * Classe Bluray, extende de PRODUTO, e é complementada pelas informações que só
 * existem para os Blurays. Como a classe PRODUTO possui um método para exibir 
 * dadosabstrato, é recomendado sobreescrevê-lo (showInfoProduto)
 * */ 

@interface Bluray : Produto
{
    @private
    NSString *titulo;
    NSString *resolucao;
}

- (id) initWithTitulo: (NSString *) t resolucao: (NSString *) r estilo: (NSString *) e codigo: (NSString *) c;

@end
