//
//  ShowInfo.h
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * Como todas as classes terão um método de consulta a suas informações
 * foi criado o protocolo ShowInfo para padronizar o nome deste método.
 * */ 

@protocol ShowInfo

- (NSString *) showInfo;

@end
