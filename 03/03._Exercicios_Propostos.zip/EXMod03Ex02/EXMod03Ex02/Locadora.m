//
//  Locadora.m
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "Locadora.h"

@implementation Locadora

- (id) init
{
    self->funcionarios = [[NSMutableArray alloc] init];
    self->usuarios = [[NSMutableArray alloc] init];
    self->produtos = [[NSMutableArray alloc] init];
    self->locacoes = [[NSMutableArray alloc] init];
    
    return self;
}

- (void) adicionarFuncionario: (Funcionario *) funcionario
{
    [self->funcionarios addObject:funcionario];
}

- (void) adicionarUsuario: (Usuario *) usuario
{
    [self->usuarios addObject:usuario];
}

- (void) adicionarProduto: (Produto *) produto
{
    [self->produtos addObject:produto];
}

- (void) adicionarLocacao: (Locacao *) locacao
{
    [self->locacoes addObject:locacao];
}

- (NSString *) listaFuncionarios
{
    NSString *buffer = @"Lista de funcionários: \n\n";
    
    // Para cada item da lista captura o seu showInfo
    for(int i=0; i<[self->funcionarios count]; i++)
    {
        NSString *temp = [[self->funcionarios objectAtIndex:i] showInfo];
        
        buffer = [buffer stringByAppendingFormat:@"%@\n\n", temp];
    }
    
    return buffer;
}

- (NSString *) listaUsuarios
{
    NSString *buffer = @"Lista de usuários: \n\n";
    
    // Para cada item da lista captura o seu showInfo
    for(int i=0; i<[self->usuarios count]; i++)
    {
        NSString *temp = [[self->usuarios objectAtIndex:i] showInfo];
        
        buffer = [buffer stringByAppendingFormat:@"%@\n\n", temp];
    }
    
    return buffer;  
}

- (NSString *) listaProdutos
{
    NSString *buffer = @"Lista de produtos: \n\n";
    
    // Para cada item da lista captura o seu showInfo
    for(int i=0; i<[self->produtos count]; i++)
    {
        NSString *temp = [[self->produtos objectAtIndex:i] showInfo];
        
        buffer = [buffer stringByAppendingFormat:@"%@\n\n", temp];
    }
    
    return buffer;
}

- (NSString *) listaLocacoes
{
    NSString *buffer = @"Lista de locações: \n\n";
    
    // Para cada item da lista captura o seu showInfo
    for(int i=0; i<[self->locacoes count]; i++)
    {
        NSString *temp = [[self->locacoes objectAtIndex:i] showInfo];
        
        buffer = [buffer stringByAppendingFormat:@"%@\n\n", temp];
    }
    
    return buffer;
}

- (Funcionario *) getFuncionarioPeloNome: (NSString *) n
{
    for(int i=0; i<[self->funcionarios count]; i++)
    {
        Funcionario *f = [self->funcionarios objectAtIndex:i];
        
        if([f getNome] == n)
        {
            return f;
        }
    }
    
    return nil;
}

- (Usuario *) getUsuarioPeloNome: (NSString *) n
{
    for(int i=0; i<[self->usuarios count]; i++)
    {
        Usuario *u = [self->usuarios objectAtIndex:i];
        
        if([u getNome] == n)
        {
            return u;
        }
    }
    
    return nil;
}

- (Produto *) getProdutoPeloCodigo: (NSString *) c
{
    for(int i=0; i<[self->produtos count]; i++)
    {
        Produto *p = [self->produtos objectAtIndex:i];
        
        if([p getCodigo] == c)
        {
            return p;
        }
    }
    
    return nil;
}

@end
