//
//  ViewController.m
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    /**************************
     *** CRIANDO A LOCADORA ***
     ***************************/
    Locadora *locadora = [[Locadora alloc] init];
    
    
    
    /******************************
     *** INSERINDO FUNCIONÁRIOS ***
     ******************************/
    Funcionario *funcionario;
    
    funcionario = [[Funcionario alloc] initWithNome:@"André" telefone:@"9999-9999" endereco:@"Rua da Softblue" salario:1000];
    [locadora adicionarFuncionario:funcionario];
    
    funcionario = [[Funcionario alloc] initWithNome:@"Carlos" telefone:@"9999-9998" endereco:@"Rua da Softblue" salario:2000];
    [locadora adicionarFuncionario:funcionario];

    
    
    /**************************
     *** INSERINDO USUÁRIOS ***
     **************************/
    Usuario *usuario;
    
    usuario = [[Usuario alloc] initWithNome:@"Fernando" telefone:@"9999-9997" endereco:@"Rua Brasil" numeroDeLocacoes:0];
    [locadora adicionarUsuario:usuario];
    
    usuario = [[Usuario alloc] initWithNome:@"Samuel" telefone:@"9999-9996" endereco:@"Rua México" numeroDeLocacoes:0];
    [locadora adicionarUsuario:usuario];
    
    
    
    /**************************
     *** INSERINDO PRODUTOS ***
     **************************/
    Produto *produto;
    
    produto = [[CD alloc] initWithArtista:@"U2" album:@"Zooropa" estilo:@"Rock" codigo:@"1"];
    [locadora adicionarProduto:produto];
    
    produto = [[DVD alloc] initWithTitulo:@"A Noite Chuvose" estilo:@"Suspense" codigo:@"2"];
    [locadora adicionarProduto:produto];
    
    produto = [[Bluray alloc] initWithTitulo:@"O Tesouro" resolucao:@"FullHD" estilo:@"Ação" codigo:@"3"];
    [locadora adicionarProduto:produto];
    
    /**************************
     *** INSERINDO LOCAÇÕES ***
     **************************/
    Locacao *locacao;
    
    // Observe que é necessário capturar os objetos pelos seus
    // nomes ou códigos, neste exemplo, para utilizá-los na criação da locação
    
    funcionario = [locadora getFuncionarioPeloNome:@"André"];
    usuario = [locadora getUsuarioPeloNome:@"Samuel"];
    produto = [locadora getProdutoPeloCodigo:@"1"];
    locacao = [[Locacao alloc] initWithFuncionario:funcionario usuario:usuario produto:produto];
    [locadora adicionarLocacao:locacao];
    
    funcionario = [locadora getFuncionarioPeloNome:@"Carlos"];
    usuario = [locadora getUsuarioPeloNome:@"Fernando"];
    produto = [locadora getProdutoPeloCodigo:@"2"];
    locacao = [[Locacao alloc] initWithFuncionario:funcionario usuario:usuario produto:produto];
    [locadora adicionarLocacao:locacao];
    
    funcionario = [locadora getFuncionarioPeloNome:@"André"];
    usuario = [locadora getUsuarioPeloNome:@"Samuel"];
    produto = [locadora getProdutoPeloCodigo:@"3"];
    locacao = [[Locacao alloc] initWithFuncionario:funcionario usuario:usuario produto:produto];
    [locadora adicionarLocacao:locacao];
    
    /*****************************************************************************************************
     *** EXIBINDO INFORMAÇÕES ****************************************************************************
     *** Serão abertas 4 UIAlertViews que serão empilhadas na tela do seu dispositivo. Por este motivo ***
     *** as telas estarão disponíveis de trás para frente, de acordo com a ordem apresentada a seguir. ***
     *****************************************************************************************************/
    
    UIAlertView *alertView;
    
    // Funcionários
    alertView = [[UIAlertView alloc] initWithTitle:@"Funcionários"
                                           message:[locadora listaFuncionarios]
                                          delegate:nil
                                 cancelButtonTitle:@"OK"
                                 otherButtonTitles:nil];
    [alertView show];
    
    // Usuários
    alertView = [[UIAlertView alloc] initWithTitle:@"Usuários"
                                           message:[locadora listaUsuarios]
                                          delegate:nil
                                 cancelButtonTitle:@"OK"
                                 otherButtonTitles:nil];
    [alertView show];
    
    // Produtos
    alertView = [[UIAlertView alloc] initWithTitle:@"Produtos"
                                           message:[locadora listaProdutos]
                                          delegate:nil
                                 cancelButtonTitle:@"OK"
                                 otherButtonTitles:nil];
    [alertView show];
    
    // Locações
    alertView = [[UIAlertView alloc] initWithTitle:@"Locações"
                                           message:[locadora listaLocacoes]
                                          delegate:nil
                                 cancelButtonTitle:@"OK"
                                 otherButtonTitles:nil];
    [alertView show];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
