//
//  Locadora.h
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Funcionario.h"
#import "Usuario.h"
#import "CD.h"
#import "DVD.h"
#import "Bluray.h"
#import "Locacao.h"

/**
 * A classe Locadora possui um array de FUNCIONARIOS, um array de USUARIOS, 
 * um array de PRODUTOS e um array de LOCACOES para organizar todas as informações
 * da locadora. Para cada um destes arrays foi criado um método de inserção de
 * dados, e um de listagem de dados.
 * */  

@interface Locadora : NSObject
{
    @private
    NSMutableArray *funcionarios;
    NSMutableArray *usuarios;
    NSMutableArray *produtos;
    NSMutableArray *locacoes;
}

- (id) init;

// Métodos de população dos dados da locadora
- (void) adicionarFuncionario: (Funcionario *) funcionario;
- (void) adicionarUsuario: (Usuario *) usuario;
- (void) adicionarProduto: (Produto *) funcionario;
- (void) adicionarLocacao: (Locacao *) locacao;

// Métodos de listagem de dados da locadora
- (NSString *) listaFuncionarios;
- (NSString *) listaUsuarios;
- (NSString *) listaProdutos;
- (NSString *) listaLocacoes;

// Métodos auxiliares para encontrar objetos a partir do nome/código
- (Funcionario *) getFuncionarioPeloNome: (NSString *) n;
- (Usuario *) getUsuarioPeloNome: (NSString *) n;
- (Produto *) getProdutoPeloCodigo: (NSString *) c;

@end
