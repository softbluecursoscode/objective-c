//
//  Produto.h
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ShowInfo.h"

/**
 * Como todo produto tem ESTILO e CODIGO, foi criado a classe PRODUTO centralizando
 * estas informações. 
 * */  

@interface Produto : NSObject <ShowInfo>
{
    // Elementos PROTECTED podem ser utilizados pela classe e suas subclasses 
    @protected
    NSString *estilo;
    NSString *codigo;
}

- (id) initWithEstilo: (NSString *) e codigo: (NSString *) c;

// Como a informação de código será utilizada mais adiante, foi criado 
// o método getCodigo para esta classe (acesso externo)
- (NSString *) getCodigo;

@end
