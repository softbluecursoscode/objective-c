//
//  Bluray.m
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "Bluray.h"

@implementation Bluray

- (id) initWithTitulo:(NSString *)t resolucao: (NSString *) r estilo:(NSString *)e codigo:(NSString *)c
{
    self = [super initWithEstilo:e codigo:c];
    
    self->titulo = t;
    self->resolucao = r;
    
    return self;
}

- (NSString *) showInfo
{
    return [[NSString alloc] initWithFormat:@"Info de Bluray: %@ %@ %@ %@",
            self->estilo,
            self->codigo,
            self->titulo,
            self->resolucao];
}

@end
