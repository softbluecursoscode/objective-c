//
//  Produto.m
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "Produto.h"

@implementation Produto

- (id) initWithEstilo: (NSString *) e codigo: (NSString *) c
{
    self->estilo = e;
    self->codigo = c;
    
    return self;
}

- (NSString *) getCodigo
{
    return self->codigo;
}

// Nesta classe não é necessário implementá-lo, mas sim, nas que herdem
- (NSString *) showInfo
{
    return @"";
}

@end
