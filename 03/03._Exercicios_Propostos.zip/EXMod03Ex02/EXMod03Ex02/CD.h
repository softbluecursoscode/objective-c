//
//  CD.h
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Produto.h"

/**
 * Classe CD, extende de PRODUTO, e é complementada pelas informações que só
 * existem para os CDs. Como a classe PRODUTO possui um método de exibição de
 * dados, sua sobreescrita é recomendada (showInfoProduto).
 * */   

@interface CD : Produto
{
    @private
    NSString *artista;
    NSString *album;
}

- (id) initWithArtista: (NSString *) ar album: (NSString *) al estilo: (NSString *) e codigo: (NSString *) c;

@end
