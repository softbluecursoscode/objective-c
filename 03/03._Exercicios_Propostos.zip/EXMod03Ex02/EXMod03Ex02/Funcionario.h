//
//  Funcionario.h
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Pessoa.h"

/**
 * A classe FUNCIONARIO extende de PESSOA, e é complementada com a informação
 * de salário. Não foi criado os métodos set e get para o atributo salário pois
 * neste exemplo esta informação só é utilizada pelo método interno de exibição
 * de dados.
 * */ 

@interface Funcionario : Pessoa <ShowInfo>
{
    @private
    float salario;
}

- (id) initWithNome: (NSString *) n telefone: (NSString *) t endereco: (NSString *) e salario: (float) s;

@end
