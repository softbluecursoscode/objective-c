//
//  DVD.m
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "DVD.h"

@implementation DVD

- (id) initWithTitulo:(NSString *)t estilo:(NSString *)e codigo:(NSString *)c
{
    self = [super initWithEstilo:e codigo:c];
    
    self->titulo = t;
    
    return self;
}

- (NSString *) showInfo
{
    return [[NSString alloc] initWithFormat:@"Info de DVD: %@ %@ %@",
            self->estilo,
            self->codigo,
            self->titulo];
}

@end
