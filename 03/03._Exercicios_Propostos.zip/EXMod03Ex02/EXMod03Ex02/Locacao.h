//
//  Locacao.h
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Funcionario.h"
#import "Usuario.h"
#import "Produto.h"
#import "ShowInfo.h"

/**
 * A classe LOCACAO representa uma locação realizada na locadora. Ela recebe
 * como parâmetros de seu método construtor um objeto FUNCIONARIO, um objeto
 * USUARIO e um objeto PRODUTO, além de atualizar o número de locações realizadas
 * pelo usuário em questão, por meio dos métodos get e set do atributo de
 * locações do usuário em questão.  
 * */   

@interface Locacao : NSObject <ShowInfo>
{
    @private
    Funcionario *funcionario;
    Usuario *usuario;
    Produto *produto;
}

- (id) initWithFuncionario: (Funcionario *) f usuario: (Usuario *) u produto: (Produto *) p;

@end
