//
//  Pessoa.h
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ShowInfo.h"

/**
 * Como classe auxiliar foi criada a classe PESSOA, com a intenção
 * de centralizar os dados comuns entre FUNCIONARIOS e USUARIOS, e também
 * para padronizar o método de exibição de informações, por meio do método
 * showInfoPessoa, que será reescrito por cada classe que herdar de PESSOA.
 * */ 

@interface Pessoa : NSObject
{
    // Elementos PROTECTED podem ser utilizados pela classe e suas subclasses    
    @protected
    NSString *nome;
    NSString *telefone;
    NSString *endereco;
}

- (id) initWithNome: (NSString *) n telefone: (NSString *) t endereco: (NSString *) e;
- (NSString *) getNome;

@end
