//
//  Funcionario.m
//  EXMod03Ex02
//
//  Created by Andre Milani on 2/4/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import "Funcionario.h"

@implementation Funcionario

// Novo construtor com o atributo numeroDeLocacoes
- (id) initWithNome: (NSString *) n telefone: (NSString *) t endereco: (NSString *) e salario: (float) s
{
    // Utilizando o construtor da super-classe para os atributos existentes nela
    self = [super initWithNome:n telefone:t endereco:e];
    
    self->salario = s;
    
    return self;
}

// Sobreescrita do método definido na classe PESSOA
- (NSString *) showInfo
{
    return [[NSString alloc] initWithFormat:@"Info de funcionário: %@ %@ %@ %f",
            self->nome,
            self->telefone,
            self->endereco,
            self->salario];
}

@end
