//
//  ViewController.m
//  SBCamera
//
//  Created by Andre Milani on 30/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize myButton;
@synthesize myImage;
@synthesize myImageView;
@synthesize myLastMediaType;
@synthesize myMoviePlayerController;
@synthesize myMovieURL;


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    // Esconde ou exibe o botão de uso da câmera, dependendo se o dispositivo possuir ou não
    
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        myButton.hidden = TRUE;
    }
    
    myImagemFrame = myImageView.frame;
    
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self updateDisplay];
}

- (IBAction) getMediaRealTime
{
    [self getMediaFromControllerSourceType: UIImagePickerControllerSourceTypeCamera];
}

- (IBAction) getMediaFromLibrary
{
    [self getMediaFromControllerSourceType: UIImagePickerControllerSourceTypePhotoLibrary];
}

// Método que gerencia a captura de arquivo da câmera ou biblioteca

- (void) getMediaFromControllerSourceType: (UIImagePickerControllerSourceType)sourceType
{
    NSArray *arrayMediaTypes = [UIImagePickerController availableMediaTypesForSourceType:sourceType];
    
    if([arrayMediaTypes count] > 0 && [UIImagePickerController isSourceTypeAvailable:sourceType])
    {
        UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
        
        imagePickerController.sourceType = sourceType;
        imagePickerController.allowsEditing = TRUE;
        imagePickerController.mediaTypes = arrayMediaTypes;
        imagePickerController.delegate = self;
        
        [self presentViewController:imagePickerController animated:TRUE completion:nil];
    }
    else
    {
        UIAlertView *myAlert = [[UIAlertView alloc] initWithTitle:@"Erro"
                                                          message:@"Dispositivo não encontrado"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [myAlert show];
    }
}

// Redimensionamento da imagem para os tamanhos do frame adicionado na tela

- (UIImage *) resizeImage:(UIImage *)image newSize: (CGSize)size
{
    CGFloat scale = [UIScreen mainScreen].scale;
    
    CGColorSpaceRef myColorSpace = CGColorSpaceCreateDeviceRGB();
    
    CGContextRef myBitmapContext = CGBitmapContextCreate(NULL,
                                               size.width * scale,
                                               size.height * scale,
                                               8, 0,
                                            myColorSpace,(CGBitmapInfo)kCGImageAlphaPremultipliedFirst);
    
    CGContextDrawImage(myBitmapContext, CGRectMake(0, 0, size.width*scale, size.height * scale), image.CGImage);
    
    CGImageRef myImageRef = CGBitmapContextCreateImage(myBitmapContext);
    
    UIImage *myResultedImage = [UIImage imageWithCGImage:myImageRef];
    
    CGContextRelease(myBitmapContext);
    CGImageRelease(myImageRef);
    
    return myResultedImage;
}

- (void) updateDisplay
{
    if([myLastMediaType isEqual:(NSString *) kUTTypeMovie])
    {
        [self.myMoviePlayerController.view removeFromSuperview];
        self.myMoviePlayerController = [[MPMoviePlayerController alloc] initWithContentURL:myMovieURL];
        
        myMoviePlayerController.view.frame = myImagemFrame;
        myMoviePlayerController.view.clipsToBounds = TRUE;
        [self.view addSubview:myMoviePlayerController.view];
        
        myImageView.hidden = TRUE;
    }
    else if([myLastMediaType isEqual:(NSString *) kUTTypeImage])
    {
        myImageView.image = myImage;
        myImageView.hidden = FALSE;
        myMoviePlayerController.view.hidden = TRUE;
    }
}

- (void) imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:TRUE completion:nil];
}

- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    myLastMediaType = [info objectForKey:UIImagePickerControllerMediaType];
    
    if([myLastMediaType isEqual:(NSString *) kUTTypeMovie])
    {
        self.myMovieURL = [info objectForKey:UIImagePickerControllerMediaURL];
    }
    else if([myLastMediaType isEqual:(NSString *) kUTTypeImage])
    {
        UIImage *chosenImage = [info objectForKey:UIImagePickerControllerEditedImage];
        UIImage *adjustedImage = [self resizeImage:chosenImage newSize:myImagemFrame.size];
        self.myImage = adjustedImage;
    }
    
    [picker dismissViewControllerAnimated:TRUE completion:nil];
}






















- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
