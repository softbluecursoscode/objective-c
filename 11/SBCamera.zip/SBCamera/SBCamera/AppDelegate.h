//
//  AppDelegate.h
//  SBCamera
//
//  Created by Andre Milani on 30/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
