//
//  ViewController.h
//  SBCamera
//
//  Created by Andre Milani on 30/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <MobileCoreServices/UTCoreTypes.h>

@interface ViewController : UIViewController
<UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
    UIImageView *myImageView;
    UIButton *myButton;
    MPMoviePlayerController *myMoviePlayerController;
    UIImage *myImage;
    NSURL *myMovieURL;
    NSString *myLastMediaType;
    CGRect myImagemFrame;
}

@property (nonatomic, retain) IBOutlet UIImageView *myImageView;
@property (nonatomic, retain) IBOutlet UIButton *myButton;
@property (nonatomic, retain) MPMoviePlayerController *myMoviePlayerController;
@property (nonatomic, retain) UIImage *myImage;
@property (nonatomic, retain) NSURL *myMovieURL;
@property (nonatomic, retain) NSString *myLastMediaType;

- (IBAction) getMediaRealTime;
- (IBAction) getMediaFromLibrary;
 

@end
