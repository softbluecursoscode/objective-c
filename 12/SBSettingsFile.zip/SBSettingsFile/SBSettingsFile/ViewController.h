//
//  ViewController.h
//  SBSettingsFile
//
//  Created by Andre Milani on 30/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UILabel *labelServidor;
    UILabel *labelPorta;
    UILabel *labelEmail;
    UILabel *labelSenha;
    UILabel *labelAutoLogin;
    UILabel *labelModo;
    UILabel *labelEspaco;
}

@property (nonatomic, retain) IBOutlet UILabel *labelServidor;
@property (nonatomic, retain) IBOutlet UILabel *labelPorta;
@property (nonatomic, retain) IBOutlet UILabel *labelEmail;
@property (nonatomic, retain) IBOutlet UILabel *labelSenha;
@property (nonatomic, retain) IBOutlet UILabel *labelAutoLogin;
@property (nonatomic, retain) IBOutlet UILabel *labelModo;
@property (nonatomic, retain) IBOutlet UILabel *labelEspaco;

- (void) getSettingsValues;

- (IBAction) buttonUpdate;

@end
