//
//  ViewController.m
//  SBSettingsFile
//
//  Created by Andre Milani on 30/10/12.
//  Copyright (c) 2012 Andre Milani. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize labelAutoLogin;
@synthesize labelEmail;
@synthesize labelEspaco;
@synthesize labelModo;
@synthesize labelPorta;
@synthesize labelSenha;
@synthesize labelServidor;

// Realiza a leitura do arquivo de configurações da aplicação

- (void) getSettingsValues
{
    NSUserDefaults *myUserDefaults = [NSUserDefaults standardUserDefaults];
    
    labelServidor.text = [myUserDefaults objectForKey:@"sbServidor"];
    labelPorta.text = [myUserDefaults objectForKey:@"sbPorta"];
    labelEmail.text = [myUserDefaults objectForKey:@"sbEmail"];
    labelSenha.text = [myUserDefaults objectForKey:@"sbSenha"];
    
    labelAutoLogin.text = [myUserDefaults boolForKey:@"sbAutoLogin"] ? @"Sim" : @"Não";
    
    labelModo.text = [myUserDefaults objectForKey:@"sbModo"];
    labelEspaco.text = [myUserDefaults stringForKey:@"sbEspaco"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    [self getSettingsValues];
}

- (IBAction) buttonUpdate
{
    [self getSettingsValues];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
