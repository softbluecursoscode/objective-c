//
//  ViewController.h
//  EXMod12Ex01
//
//  Created by Andre Milani on 2/6/12.
//  Copyright (c) 2012 Softblue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UILabel *basNomeDeUsuarioLabel;
    UILabel *basEmailLabel;
    UILabel *basSenhaLabel;
    UILabel *basReceberEmailsLabel;
    UILabel *avConhecimentoLabel;
    
}

@property (nonatomic, retain) IBOutlet UILabel *basNomeDeUsuarioLabel;
@property (nonatomic, retain) IBOutlet UILabel *basEmailLabel;
@property (nonatomic, retain) IBOutlet UILabel *basSenhaLabel;
@property (nonatomic, retain) IBOutlet UILabel *basReceberEmailsLabel;
@property (nonatomic, retain) IBOutlet UILabel *avConhecimentoLabel;

- (void) updateFields;

@end
